# HUAI MONG SMART WATER COMMAND CENTER
## เอกสารสถาปัตยกรรมระบบและแบบจำลองข้อมูล (Architecture & Data Model)

### 1. ภาพรวมสถาปัตยกรรม (System Architecture)
```
+-----------------------------------------------------------------------------------+
|                        EXECUTIVE WEB DASHBOARD (FRONTEND)                         |
|   - Responsive UI (ห้องประชุม / Desktop / Tablet / Mobile)                        |
|   - Leaflet GIS Digital Twin (1,723 Spatial Assets, WGS84 EPSG:4326)              |
|   - Buddhist Era (พ.ศ. 2569), Asia/Bangkok Timezone, RID Professional Color Theme|
|   - Hydraulic Simulator Interface & Interactive Modals                            |
+-----------------------------------------------------------------------------------+
                                        | (REST API / JSON / Streams)
                                        v
+-----------------------------------------------------------------------------------+
|                           FASTAPI APPLICATION SERVER                              |
|   - 10 Core Business Modules + AI Decision Support Engine                         |
|   - Export Engine: XlsxWriter (Excel) & Python-PPTX (PowerPoint 16:9 Slides)       |
|   - GIS Ingestion & Topology QA/QC Validation Pipeline                            |
|   - Role-Based Access Control (RBAC) & Audit Logging                              |
+-----------------------------------------------------------------------------------+
                                        |
                   +--------------------+--------------------+
                   |                                         |
                   v                                         v
+-------------------------------------+   +-------------------------------------+
|        SPATIAL & TIME-SERIES DB     |   |       EXTERNAL DATA CONNECTORS      |
|  - PostgreSQL / PostGIS (Docker)    |   |  - RID Telemetry API (Read-only)    |
|  - SQLite3 Standalone (Zero-config) |   |  - TMD Weather & Rainfall API       |
|  - 10 Tables: assets, telemetry,    |   |  - ONWR / MRC Mekong Level API      |
|    zones, hydrology, inspections,   |   |  - QA/QC Ingestion / Status 'รอข้อมูล'|
|    budget, KPIs, incidents, logs    |   +-------------------------------------+
+-------------------------------------+
```

### 2. โมเดลข้อมูลและการจำแนกสินทรัพย์ (Asset Classification Matrix)
| รหัสหมวด | ชื่อประเภทสินทรัพย์ทางการ | จำนวนองค์ประกอบ | ระดับความสำคัญ |
|---|---|---|---|
| `regulator` | อาคารบังคับน้ำ / ปตร.ปากห้วยโมง | 2 | CRITICAL |
| `pumping_station` | สถานีสูบน้ำด้วยไฟฟ้า P1-P10 | 16 | MAJOR |
| `dike` | คันกั้นน้ำห้วยโมง | 5 | MAJOR |
| `main_canal` | คลองส่งน้ำสายใหญ่ (Mcanal) | 55 | MAJOR |
| `sub_canal` | คลองส่งน้ำสายซอย (Lateral) | 8 | STANDARD |
| `drainage_canal` | คลองระบายน้ำ (Dcanal) | 38 | STANDARD |
| `ditch` | คูส่งน้ำชลประทาน (Ditch) | 318 | STANDARD |
| `reservoir` | อ่างเก็บน้ำห้วยโมง / ห้วยลาน | 2 | CRITICAL |
| `irrigation_zone` | พื้นที่โซนชลประทาน (Zone) | 11 | MAJOR |
| `cadastral_boundary` | แนวเขตที่ดิน นสล. / เขต ชป. | 1,263 | REFERENCE |
| `electrical_substation` | สถานีย่อยจ่ายกระแสไฟฟ้า (ELS) | 1 | MAJOR |
| `general_facility` | สิ่งก่อสร้างและองค์ประกอบทั่วไป | 4 | STANDARD |
| **รวมทั้งหมด** | | **1,723 รายการ** | |
