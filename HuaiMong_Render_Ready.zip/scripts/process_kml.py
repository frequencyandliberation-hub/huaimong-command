import xml.etree.ElementTree as ET
import json
import math
import os
import sys

def haversine_distance(coord1, coord2):
    R = 6371000.0  # Earth radius in meters
    lon1, lat1 = math.radians(coord1[0]), math.radians(coord1[1])
    lon2, lat2 = math.radians(coord2[0]), math.radians(coord2[1])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat / 2.0)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2.0)**2
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    return R * c

def calculate_linestring_length(coords):
    total = 0.0
    for i in range(len(coords) - 1):
        total += haversine_distance(coords[i], coords[i+1])
    return total

def calculate_polygon_area(coords):
    if len(coords) < 3:
        return 0.0
    area = 0.0
    R = 6371000.0
    rad_coords = [(math.radians(p[0]), math.radians(p[1])) for p in coords]
    for i in range(len(rad_coords) - 1):
        p1 = rad_coords[i]
        p2 = rad_coords[i+1]
        area += (p2[0] - p1[0]) * (2.0 + math.sin(p1[1]) + math.sin(p2[1]))
    area = abs(area * (R**2) / 2.0)
    return area

def parse_coords_str(c_str):
    res = []
    tokens = c_str.strip().split()
    for token in tokens:
        parts = token.strip().split(',')
        if len(parts) >= 2:
            try:
                lon = float(parts[0])
                lat = float(parts[1])
                alt = float(parts[2]) if len(parts) > 2 else 0.0
                res.append([lon, lat, alt])
            except ValueError:
                continue
    return res

def classify_asset(folder_path, name):
    fp_lower = folder_path.lower()
    nm_lower = name.lower()
    
    if 'kh.18' in nm_lower or 'สถานีวัดน้ำ' in nm_lower:
        return 'hydrological_station', 'สถานีวัดน้ำท่า/อุทกวิทยา (Kh.18)', 'CRITICAL'
    elif 'regulator' in nm_lower or 'ปตร' in nm_lower or 'อาคารบังคับ' in nm_lower:
        return 'regulator', 'อาคารบังคับน้ำ/ปตร.ปากห้วยโมง', 'CRITICAL'
    elif 'station' in fp_lower or (name.startswith('P') and any(char.isdigit() for char in name) and len(name) <= 5):
        return 'pumping_station', 'สถานีสูบน้ำด้วยไฟฟ้า (P1-P10)', 'MAJOR'
    elif 'dike' in fp_lower or 'คันกั้นน้ำ' in fp_lower or 'dike' in nm_lower:
        return 'dike', 'คันกั้นน้ำห้วยโมง', 'MAJOR'
    elif 'mcanal' in fp_lower or 'คลองสายใหญ่' in fp_lower:
        return 'main_canal', 'คลองส่งน้ำสายใหญ่ (Mcanal)', 'MAJOR'
    elif 'dcanal' in fp_lower or 'คลองระบาย' in fp_lower:
        return 'drainage_canal', 'คลองระบายน้ำ (Dcanal)', 'STANDARD'
    elif 'ditch' in fp_lower or 'คูส่งน้ำ' in fp_lower:
        return 'ditch', 'คูส่งน้ำชลประทาน (Ditch)', 'STANDARD'
    elif 'canal' in fp_lower or 'คลอง' in fp_lower:
        return 'sub_canal', 'คลองส่งน้ำสายซอย (Lateral)', 'STANDARD'
    elif 'zonemap' in fp_lower or 'zone_' in nm_lower or 'zone' in nm_lower:
        return 'irrigation_zone', 'พื้นที่โซนชลประทาน (Zone)', 'MAJOR'
    elif 'อ่างเก็บน้ำ' in fp_lower or 'อ่าง' in nm_lower:
        return 'reservoir', 'อ่างเก็บน้ำ / แหล่งน้ำต้นทุน', 'CRITICAL'
    elif 'กองนาง' in fp_lower or 'หนองอ้อ' in fp_lower or 'กันเขต' in fp_lower or 'นสล' in fp_lower:
        return 'cadastral_boundary', 'แนวเขตที่ดิน/หลักเขตชลประทาน', 'REFERENCE'
    elif 'els' in fp_lower:
        return 'electrical_substation', 'สถานีย่อยจ่ายกระแสไฟฟ้า', 'MAJOR'
    elif 'พื้นที่' in nm_lower:
        return 'irrigation_area', 'พื้นที่โครงการ/ประโยชน์', 'STANDARD'
    else:
        return 'general_facility', 'สิ่งก่อสร้างและองค์ประกอบทั่วไป', 'STANDARD'

def process_kml(kml_path, output_geojson_path, output_report_path, output_dict_path):
    print(f"Reading KML from: {kml_path}")
    tree = ET.parse(kml_path)
    root = tree.getroot()
    ns = {'kml': 'http://www.opengis.net/kml/2.2', 'gx': 'http://www.google.com/kml/ext/2.2'}
    
    features = []
    seen_names = {}
    seen_coords = set()
    
    qa_report = {
        "source_file": os.path.basename(kml_path),
        "crs_expected": "EPSG:4326 (WGS84)",
        "crs_validated": True,
        "total_elements": {
            "placemarks": 0,
            "points": 0,
            "linestrings": 0,
            "polygons": 0,
            "multigeometries": 0
        },
        "coordinate_bounds": {
            "min_lon": 999.0,
            "max_lon": -999.0,
            "min_lat": 999.0,
            "max_lat": -999.0
        },
        "bounds_expected_region": "Huai Mong Basin, Nong Khai (Lat ~17.5-18.2, Lon ~102.3-103.0)",
        "bounds_validation_passed": True,
        "invalid_coordinates_count": 0,
        "zero_length_linestrings": 0,
        "invalid_polygons": 0,
        "duplicate_names_count": 0,
        "duplicate_coordinates_count": 0,
        "classification_summary": {},
        "geometry_type_breakdown": {},
        "data_gap_analysis": {
            "attributes_present_in_kml": ["name", "folder_path", "description (partial)", "coordinates", "geometry_type"],
            "attributes_missing_for_executive_operations": [
                "rid_asset_code (รหัสสินทรัพย์ทางการกรมชลประทาน)",
                "design_capacity_m3_s (อัตราการไหลออกแบบ ลบ.ม./วินาที)",
                "actual_discharge_m3_s (อัตราการไหลส่งน้ำจริง ลบ.ม./วินาที)",
                "water_elevation_msl (ระดับน้ำ ม.รทก.)",
                "construction_year_be (ปี พ.ศ. ก่อสร้าง)",
                "condition_score (คะแนนสภาพ 1-5 หรือ ผ่าน/ชำรุด)",
                "latest_inspection_date (วันที่ตรวจสภาพล่าสุด)",
                "telemetry_station_id (รหัสสถานีโทรมาตรเรียลไทม์)",
                "gate_opening_m (ระดับการเปิดบานประตูระบายน้ำ)",
                "pump_operating_units (จำนวนเครื่องสูบน้ำที่กำลังทำงาน)"
            ],
            "operating_rule": "ใช้สถานะ 'รอข้อมูล' สำหรับค่าปฏิบัติการที่ยังไม่มีการเชื่อมต่อเซนเซอร์หรือ API จริง ห้ามแต่งตัวเลขปฏิบัติการขึ้นเอง"
        }
    }

    def walk_container(elem, current_path=""):
        name_el = elem.find('kml:name', ns)
        c_name = name_el.text.strip() if (name_el is not None and name_el.text) else ""
        next_path = f"{current_path}/{c_name}" if current_path and c_name else (c_name if c_name else current_path)
        
        # Process direct placemarks
        for pm in elem.findall('kml:Placemark', ns):
            process_placemark(pm, next_path)
            
        # Recurse into child containers (Folder and Document)
        for child in elem:
            c_tag = child.tag.split('}')[-1]
            if c_tag in ('Folder', 'Document'):
                walk_container(child, next_path)

    def process_placemark(pm, folder_path):
        qa_report["total_elements"]["placemarks"] += 1
        name_elem = pm.find('kml:name', ns)
        pm_name = name_elem.text.strip() if (name_elem is not None and name_elem.text) else "ไม่ระบุชื่อ"
        
        desc_elem = pm.find('kml:description', ns)
        pm_desc = desc_elem.text.strip() if (desc_elem is not None and desc_elem.text) else ""
        
        seen_names[pm_name] = seen_names.get(pm_name, 0) + 1
        cat_code, cat_label, criticality = classify_asset(folder_path, pm_name)
        
        multi = pm.find('.//kml:MultiGeometry', ns)
        if multi is not None:
            qa_report["total_elements"]["multigeometries"] += 1
            
        # Points
        for pt in pm.findall('.//kml:Point', ns):
            qa_report["total_elements"]["points"] += 1
            c_elem = pt.find('kml:coordinates', ns)
            if c_elem is not None and c_elem.text:
                coords = parse_coords_str(c_elem.text)
                if coords:
                    p = coords[0]
                    add_feat("Point", [p[0], p[1]], pm_name, folder_path, cat_code, cat_label, criticality, pm_desc)
                    
        # LineStrings
        for ls in pm.findall('.//kml:LineString', ns):
            qa_report["total_elements"]["linestrings"] += 1
            c_elem = ls.find('kml:coordinates', ns)
            if c_elem is not None and c_elem.text:
                coords = parse_coords_str(c_elem.text)
                if len(coords) >= 2:
                    coords_2d = [[p[0], p[1]] for p in coords]
                    length_m = calculate_linestring_length(coords_2d)
                    if length_m < 0.1:
                        qa_report["zero_length_linestrings"] += 1
                    add_feat("LineString", coords_2d, pm_name, folder_path, cat_code, cat_label, criticality, pm_desc, length_m=length_m)
                else:
                    qa_report["invalid_coordinates_count"] += 1
                    
        # Polygons
        for poly in pm.findall('.//kml:Polygon', ns):
            qa_report["total_elements"]["polygons"] += 1
            outer = poly.find('.//kml:outerBoundaryIs//kml:coordinates', ns)
            if outer is not None and outer.text:
                coords = parse_coords_str(outer.text)
                if len(coords) >= 3:
                    coords_2d = [[p[0], p[1]] for p in coords]
                    if coords_2d[0] != coords_2d[-1]:
                        coords_2d.append(coords_2d[0])
                    area_m2 = calculate_polygon_area(coords_2d)
                    add_feat("Polygon", [coords_2d], pm_name, folder_path, cat_code, cat_label, criticality, pm_desc, area_m2=area_m2)
                else:
                    qa_report["invalid_polygons"] += 1

    def add_feat(geom_type, coords, name, folder_path, cat_code, cat_label, criticality, desc, length_m=None, area_m2=None):
        qa_report["geometry_type_breakdown"][geom_type] = qa_report["geometry_type_breakdown"].get(geom_type, 0) + 1
        qa_report["classification_summary"][cat_label] = qa_report["classification_summary"].get(cat_label, 0) + 1
        
        pts = [coords] if geom_type == "Point" else (coords if geom_type == "LineString" else coords[0])
        for pt in pts:
            lon, lat = pt[0], pt[1]
            if lon < qa_report["coordinate_bounds"]["min_lon"]: qa_report["coordinate_bounds"]["min_lon"] = lon
            if lon > qa_report["coordinate_bounds"]["max_lon"]: qa_report["coordinate_bounds"]["max_lon"] = lon
            if lat < qa_report["coordinate_bounds"]["min_lat"]: qa_report["coordinate_bounds"]["min_lat"] = lat
            if lat > qa_report["coordinate_bounds"]["max_lat"]: qa_report["coordinate_bounds"]["max_lat"] = lat
            if not (102.0 <= lon <= 103.5 and 17.4 <= lat <= 18.5):
                qa_report["invalid_coordinates_count"] += 1
                
        fp = f"{geom_type}_{len(pts)}_{round(pts[0][0], 5)}_{round(pts[0][1], 5)}"
        if fp in seen_coords:
            qa_report["duplicate_coordinates_count"] += 1
        else:
            seen_coords.add(fp)
            
        fid = f"HM-{len(features)+1:04d}"
        features.append({
            "type": "Feature",
            "id": fid,
            "geometry": {
                "type": geom_type,
                "coordinates": coords
            },
            "properties": {
                "id": fid,
                "name": name,
                "folder_path": folder_path,
                "category_code": cat_code,
                "category_label": cat_label,
                "criticality": criticality,
                "description": desc,
                "length_km": round(length_m / 1000.0, 3) if length_m is not None else None,
                "area_rai": round(area_m2 / 1600.0, 2) if area_m2 is not None else None,
                "status_operation": "รอข้อมูล",
                "status_inspection": "รอข้อมูล",
                "condition_score": "รอข้อมูล",
                "water_elevation_msl": "รอข้อมูล",
                "discharge_m3_s": "รอข้อมูล",
                "design_capacity": "รอข้อมูล",
                "responsible_unit": "ฝ่ายจัดสรรน้ำและปรับปรุงระบบชลประทาน ห้วยโมง",
                "data_lineage": "KML -> GeoJSON Validation Pipeline"
            }
        })

    # Start recursion
    top_doc = root.find('kml:Document', ns)
    if top_doc is not None:
        walk_container(top_doc, "")
    else:
        walk_container(root, "")
        
    qa_report["duplicate_names_count"] = sum(c - 1 for c in seen_names.values() if c > 1)
    b = qa_report["coordinate_bounds"]
    if not (102.0 <= b["min_lon"] <= 103.5 and 17.4 <= b["min_lat"] <= 18.5):
        qa_report["bounds_validation_passed"] = False

    geojson = {
        "type": "FeatureCollection",
        "metadata": {
            "title": "โครงการส่งน้ำและบำรุงรักษาห้วยโมง จังหวัดหนองคาย - GIS Digital Twin",
            "total_features": len(features),
            "generated_at": "2569-10-19T11:45:00+07:00",
            "coordinate_system": "EPSG:4326 (WGS84)",
            "bounds": [
                [qa_report["coordinate_bounds"]["min_lat"], qa_report["coordinate_bounds"]["min_lon"]],
                [qa_report["coordinate_bounds"]["max_lat"], qa_report["coordinate_bounds"]["max_lon"]]
            ]
        },
        "features": features
    }
    
    data_dict = {
        "dataset_name": "Huai Mong Spatial Asset Registry",
        "version": "1.0.0",
        "crs": "EPSG:4326 (WGS84)",
        "attributes": {
            "id": {"type": "string", "description": "รหัสระบบสินทรัพย์ (Feature ID)"},
            "name": {"type": "string", "description": "ชื่อสินทรัพย์/ชื่อสายคลอง/หมุดพิกัด"},
            "folder_path": {"type": "string", "description": "โครงสร้างโฟลเดอร์ต้นทาง"},
            "category_code": {"type": "string", "description": "รหัสหมวดสินทรัพย์"},
            "category_label": {"type": "string", "description": "ชื่อหมวดหมู่ทางการภาษาไทย"},
            "criticality": {"type": "string", "description": "ระดับความวิกฤต (CRITICAL, MAJOR, STANDARD, REFERENCE)"},
            "length_km": {"type": "float", "description": "ความยาวตามแนวเส้น (กิโลเมตร)"},
            "area_rai": {"type": "float", "description": "พื้นที่ระนาบผิว (ไร่)"},
            "status_operation": {"type": "string", "description": "สถานะการทำงาน (เช่น รอข้อมูล/ปกติ/เปิด)"},
            "status_inspection": {"type": "string", "description": "สถานะการตรวจสภาพ"},
            "condition_score": {"type": "string", "description": "คะแนนสภาพสินทรัพย์"},
            "water_elevation_msl": {"type": "string", "description": "ระดับน้ำ ม.รทก."},
            "discharge_m3_s": {"type": "string", "description": "อัตราการไหล ลบ.ม./วินาที"}
        },
        "categories_summary": qa_report["classification_summary"]
    }
    
    with open(output_geojson_path, 'w', encoding='utf-8') as f:
        json.dump(geojson, f, ensure_ascii=False, indent=2)
        
    with open(output_report_path, 'w', encoding='utf-8') as f:
        json.dump(qa_report, f, ensure_ascii=False, indent=2)
        
    with open(output_dict_path, 'w', encoding='utf-8') as f:
        json.dump(data_dict, f, ensure_ascii=False, indent=2)

    print(f"COMPLETE: {len(features)} total features processed.")
    print(f"Placemarks counted: {qa_report['total_elements']['placemarks']}")
    print(f"Points: {qa_report['total_elements']['points']}, LineStrings: {qa_report['total_elements']['linestrings']}, Polygons: {qa_report['total_elements']['polygons']}")
    for k, v in qa_report["classification_summary"].items():
        print(f"   {k}: {v}")

if __name__ == '__main__':
    process_kml('data/huaimong.kml', 'data/huaimong_assets.geojson', 'data/kml_validation_report.json', 'data/data_dictionary.json')
