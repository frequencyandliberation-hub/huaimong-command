import json
import os
import sqlite3
import math
from datetime import datetime

DB_PATH = 'data/huaimong.db'

def detect_category(filename, props, geom_type):
    fn_lower = filename.lower()
    props_str = json.dumps(props, ensure_ascii=False).lower()
    
    # Priority 1: Subdistrict (Tambon) - Must check first because tambon props contain parent amp_code/amp_th
    if any(k in props for k in ['tam_code', 'tam_th', 'tam_en', 'tambon']) or 'tambon' in fn_lower or 'subdistrict' in fn_lower or 'ตำบล' in fn_lower:
        return 'subdistrict_boundary', 'ขอบเขตตำบล (Subdistrict Boundary)', 'REFERENCE'
    elif any(k in props for k in ['amp_code', 'amp_th', 'amp_en', 'amphoe']) or 'district' in fn_lower or 'อำเภอ' in fn_lower:
        return 'district_boundary', 'ขอบเขตอำเภอ (District Boundary)', 'REFERENCE'
    elif any(k in props for k in ['pro_code', 'pro_th', 'pro_en', 'province', 'changwat']) or 'province' in fn_lower or 'จังหวัด' in fn_lower:
        return 'province_boundary', 'ขอบเขตจังหวัด (Province Boundary)', 'REFERENCE'
    elif 'basin' in fn_lower or 'ลุ่มน้ำ' in fn_lower or 'watershed' in fn_lower:
        return 'basin_boundary', 'ขอบเขตลุ่มน้ำ (Basin Boundary)', 'MAJOR'
    elif 'moo' in props_str or 'village' in props_str or 'หมู่บ้าน' in props_str:
        return 'village_point', 'จุดที่ตั้งหมู่บ้าน (Village)', 'STANDARD'
    elif 'polygon' in geom_type.lower():
        return 'custom_boundary', 'ขอบเขตพื้นที่เชิงพื้นที่ (Spatial Boundary)', 'STANDARD'
    elif 'line' in geom_type.lower():
        return 'custom_line', 'แนวเส้นโครงข่าย (Network Line)', 'STANDARD'
    else:
        return 'custom_point', 'จุดพิกัดตำแหน่ง (Spatial Point)', 'STANDARD'

def extract_name(props, category_code, index):
    if category_code == 'subdistrict_boundary':
        tam_th = props.get('tam_th') or props.get('tam_en') or props.get('name') or props.get('NAME')
        amp_th = props.get('amp_th') or props.get('amp_en') or ''
        pro_th = props.get('pro_th') or props.get('pro_en') or ''
        if tam_th:
            prefix_tam = "ตำบล" if not tam_th.startswith("ตำบล") and not tam_th.startswith("ต.") else ""
            amp_clean = amp_th.replace("อำเภอ", "").replace("อ.", "").strip()
            amp_str = f" อ.{amp_clean}" if amp_clean else ""
            pro_clean = pro_th.replace("จังหวัด", "").replace("จ.", "").strip()
            pro_str = f" จ.{pro_clean}" if pro_clean else ""
            return f"{prefix_tam}{tam_th}{amp_str}{pro_str}".strip()
    elif category_code == 'district_boundary':
        amp_th = props.get('amp_th') or props.get('amp_en') or props.get('name') or props.get('NAME')
        pro_th = props.get('pro_th') or props.get('pro_en') or ''
        if amp_th:
            prefix = "อำเภอ" if not amp_th.startswith("อำเภอ") and not amp_th.startswith("อ.") else ""
            pro_clean = pro_th.replace("จังหวัด", "").replace("จ.", "").strip()
            pro_str = f" จ.{pro_clean}" if pro_clean else ""
            return f"{prefix}{amp_th}{pro_str}".strip()
            
    for k in ['name', 'NAME', 'Name', 'title', 'Title', 'tam_th', 'amp_th', 'pro_th', 'description']:
        if k in props and props[k]:
            return str(props[k]).strip()
            
    return f"องค์ประกอบนำเข้า #{index+1}"

def ingest_geojson_file(filepath, conn):
    filename = os.path.basename(filepath)
    print(f"Ingesting: {filename}")
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
        
    features = data.get('features', [])
    c = conn.cursor()
    now = datetime.now().isoformat()
    ingested_count = 0
    
    for i, feat in enumerate(features):
        props = feat.get('properties', {})
        geom = feat.get('geometry', {})
        geom_type = geom.get('type', 'Unknown')
        
        cat_code, cat_label, criticality = detect_category(filename, props, geom_type)
        name = extract_name(props, cat_code, i)
        
        # ID detection
        feat_id = None
        if 'tam_code' in props:
            feat_id = f"SUBDIST-{props['tam_code']}"
        elif 'amp_code' in props:
            feat_id = f"DIST-{props['amp_code']}"
        elif 'pro_code' in props:
            feat_id = f"PROV-{props['pro_code']}"
        elif 'id' in feat:
            feat_id = f"UP-{feat['id']}"
        elif 'id' in props:
            feat_id = f"UP-{props['id']}"
        else:
            clean_fn = "".join(ch for ch in filename if ch.isalnum())[:8]
            feat_id = f"UP-{clean_fn}-{i+1:04d}"
            
        # Area in rai
        area_rai = None
        if 'area_sqkm' in props and props['area_sqkm']:
            try:
                area_rai = round(float(props['area_sqkm']) * 625.0, 2) # 1 sqkm = 625 rai
            except Exception:
                pass
                
        # Insert or replace in assets
        c.execute('''
        INSERT OR REPLACE INTO assets (
            id, name, folder_path, category_code, category_label, criticality,
            length_km, area_rai, geometry_geojson, status_operation, status_inspection,
            condition_score, water_elevation_msl, discharge_m3_s, design_capacity,
            responsible_unit, data_lineage, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            feat_id,
            name,
            f"Uploaded/{filename}",
            cat_code,
            cat_label,
            criticality,
            props.get('perimeter'),
            area_rai,
            json.dumps(geom, ensure_ascii=False),
            'ขอบเขตการปกครอง/แผนที่ฐาน',
            'ตรวจสอบ CRS EPSG:4326 แล้ว',
            'ปกติ',
            '-',
            '-',
            '-',
            'กรมการปกครอง / ข้อมูลเชิงพื้นที่บูรณาการ',
            f"Uploaded File: {filename} (QA/QC Ingestion)",
            now,
            now
        ))
        ingested_count += 1
        
    conn.commit()
    print(f"Successfully ingested {ingested_count} features from {filename}")
    return ingested_count

if __name__ == '__main__':
    conn = sqlite3.connect(DB_PATH)
    for fn in ['data/uploaded_District_NK_BK.geojson', 'data/uploaded_Tambon_NK_BK.geojson']:
        if os.path.exists(fn):
            ingest_geojson_file(fn, conn)
    conn.close()
