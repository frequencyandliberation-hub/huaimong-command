-- =========================================================================
-- HUAI MONG SMART WATER COMMAND CENTER - DATABASE SCHEMA (PostgreSQL / PostGIS)
-- โครงการส่งน้ำและบำรุงรักษาห้วยโมง จังหวัดหนองคาย
-- =========================================================================

CREATE EXTENSION IF NOT EXISTS postgis;

-- 1. ASSET REGISTRY & DIGITAL TWIN
CREATE TABLE IF NOT EXISTS assets (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    folder_path VARCHAR(500),
    category_code VARCHAR(64) NOT NULL,
    category_label VARCHAR(255) NOT NULL,
    criticality VARCHAR(32) DEFAULT 'STANDARD', -- CRITICAL, MAJOR, STANDARD, REFERENCE
    length_km NUMERIC(10,3),
    area_rai NUMERIC(12,2),
    geom GEOMETRY(Geometry, 4326),
    geometry_geojson TEXT,
    status_operation VARCHAR(64) DEFAULT 'รอข้อมูล',
    status_inspection VARCHAR(64) DEFAULT 'รอข้อมูล',
    condition_score VARCHAR(32) DEFAULT 'รอข้อมูล',
    water_elevation_msl VARCHAR(32) DEFAULT 'รอข้อมูล',
    discharge_m3_s VARCHAR(32) DEFAULT 'รอข้อมูล',
    design_capacity VARCHAR(64) DEFAULT 'รอข้อมูล',
    responsible_unit VARCHAR(255) DEFAULT 'ฝ่ายส่งน้ำและบำรุงรักษา โครงการฯ ห้วยโมง',
    data_lineage VARCHAR(255) DEFAULT 'KML / GeoJSON Official Import',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_assets_category ON assets(category_code);
CREATE INDEX IF NOT EXISTS idx_assets_criticality ON assets(criticality);

-- 2. WATER OPERATIONS & TELEMETRY
CREATE TABLE IF NOT EXISTS water_telemetry (
    id SERIAL PRIMARY KEY,
    station_id VARCHAR(64) NOT NULL,
    station_name VARCHAR(255) NOT NULL,
    recorded_at TIMESTAMP WITH TIME ZONE NOT NULL,
    water_level_upstream_msl NUMERIC(6,2),
    water_level_downstream_msl NUMERIC(6,2),
    discharge_m3_s NUMERIC(8,2),
    gate_opening_m NUMERIC(4,2),
    active_pumps INTEGER DEFAULT 0,
    pump_capacity_total_m3_s NUMERIC(8,2),
    status VARCHAR(64) DEFAULT 'ปกติ',
    data_source VARCHAR(255) DEFAULT 'สถานีโทรมาตร ชป. ห้วยโมง',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_water_telemetry_station ON water_telemetry(station_id, recorded_at);

-- 3. IRRIGATION SERVICE & EQUITY
CREATE TABLE IF NOT EXISTS irrigation_zones (
    id VARCHAR(64) PRIMARY KEY,
    zone_code VARCHAR(32) NOT NULL,
    zone_name VARCHAR(255) NOT NULL,
    station_ref VARCHAR(64),
    target_area_rai NUMERIC(10,2) DEFAULT 0.0,
    actual_irrigated_rai NUMERIC(10,2) DEFAULT 0.0,
    crop_type VARCHAR(128) DEFAULT 'ข้าวนาปรัง / พืชไร่',
    farmer_count INTEGER DEFAULT 0,
    water_demand_m3 NUMERIC(14,2) DEFAULT 0.0,
    water_delivered_m3 NUMERIC(14,2) DEFAULT 0.0,
    rotational_schedule VARCHAR(255) DEFAULT 'ตามรอบเวรการส่งน้ำ ชป.',
    equity_index NUMERIC(4,2) DEFAULT 1.0, -- 1.0 = เท่าเทียมสมบูรณ์
    complaint_count INTEGER DEFAULT 0,
    resolved_count INTEGER DEFAULT 0,
    status VARCHAR(64) DEFAULT 'ปกติ'
);

-- 4. HYDROLOGY, FLOOD & DROUGHT
CREATE TABLE IF NOT EXISTS hydrological_monitoring (
    id SERIAL PRIMARY KEY,
    station_code VARCHAR(64) NOT NULL,
    station_name VARCHAR(255) NOT NULL,
    recorded_at TIMESTAMP WITH TIME ZONE NOT NULL,
    rainfall_24h_mm NUMERIC(6,1) DEFAULT 0.0,
    water_level_msl NUMERIC(6,2),
    warning_level_msl NUMERIC(6,2),
    critical_level_msl NUMERIC(6,2),
    mekong_level_msl NUMERIC(6,2),
    trend VARCHAR(32) DEFAULT 'ทรงตัว', -- เพิ่มขึ้น, ลดลง, ทรงตัว
    risk_level VARCHAR(32) DEFAULT 'ปกติ', -- ปกติ, เฝ้าระวัง, เตือนภัย, วิกฤต
    status_note TEXT
);

-- 5. ASSET CONDITION & MAINTENANCE
CREATE TABLE IF NOT EXISTS asset_inspections (
    id SERIAL PRIMARY KEY,
    asset_id VARCHAR(64) REFERENCES assets(id),
    inspection_date DATE NOT NULL,
    inspector_name VARCHAR(255) NOT NULL,
    condition_rating INTEGER CHECK (condition_rating BETWEEN 1 AND 5),
    condition_description TEXT,
    defects_found TEXT,
    urgent_repair_needed BOOLEAN DEFAULT FALSE,
    estimated_repair_cost_thb NUMERIC(12,2) DEFAULT 0.0,
    maintenance_status VARCHAR(64) DEFAULT 'รอการจัดสรรงบ',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. BUDGET & PROJECTS
CREATE TABLE IF NOT EXISTS budget_projects (
    id VARCHAR(64) PRIMARY KEY,
    project_name VARCHAR(255) NOT NULL,
    fiscal_year_be INTEGER NOT NULL,
    budget_category VARCHAR(128) NOT NULL,
    allocated_thb NUMERIC(14,2) NOT NULL,
    disbursed_thb NUMERIC(14,2) DEFAULT 0.0,
    disbursement_percent NUMERIC(5,2) GENERATED ALWAYS AS (
        CASE WHEN allocated_thb > 0 THEN ROUND((disbursed_thb / allocated_thb) * 100.0, 2) ELSE 0.0 END
    ) STORED,
    physical_progress_percent NUMERIC(5,2) DEFAULT 0.0,
    contractor VARCHAR(255),
    contract_end_date DATE,
    risk_level VARCHAR(32) DEFAULT 'ต่ำ',
    beneficiary_households INTEGER DEFAULT 0,
    beneficiary_area_rai NUMERIC(10,2) DEFAULT 0.0
);

-- 7. STRATEGIC KPIS
CREATE TABLE IF NOT EXISTS strategic_kpis (
    id VARCHAR(64) PRIMARY KEY,
    kpi_code VARCHAR(32) NOT NULL,
    kpi_name VARCHAR(255) NOT NULL,
    category VARCHAR(128) NOT NULL,
    formula_expression TEXT NOT NULL,
    unit VARCHAR(64) NOT NULL,
    data_owner VARCHAR(255) NOT NULL,
    frequency VARCHAR(64) NOT NULL,
    official_reference TEXT NOT NULL,
    is_official_verified BOOLEAN DEFAULT FALSE, -- ข้อเสนอจนกว่าจะรับรอง
    target_value NUMERIC(12,2),
    actual_value NUMERIC(12,2),
    achievement_percent NUMERIC(5,2),
    status VARCHAR(64) DEFAULT 'รอข้อมูล'
);

-- 8. COMMAND CENTER INCIDENTS
CREATE TABLE IF NOT EXISTS command_incidents (
    id VARCHAR(64) PRIMARY KEY,
    incident_title VARCHAR(255) NOT NULL,
    category VARCHAR(64) NOT NULL,
    severity VARCHAR(32) NOT NULL, -- วิกฤต, สูง, ปานกลาง, ต่ำ
    location_description VARCHAR(255),
    asset_id VARCHAR(64),
    reported_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    due_date TIMESTAMP WITH TIME ZONE,
    assigned_officer VARCHAR(255),
    assigned_department VARCHAR(255),
    executive_directive TEXT,
    action_taken TEXT,
    evidence_url VARCHAR(500),
    status VARCHAR(32) DEFAULT 'ค้างดำเนินการ', -- ค้างดำเนินการ, กำลังแก้ไข, รอตรวจรับ, ปิดงาน
    closed_at TIMESTAMP WITH TIME ZONE
);

-- 9. USER ROLES & ACCESS CONTROL
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    role VARCHAR(32) NOT NULL, -- EXECUTIVE, WATER_OPERATOR, ASSET_ENGINEER, BUDGET_OFFICER, DATA_OFFICER, PUBLIC_VIEWER
    department VARCHAR(255),
    email VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 10. AUDIT LOGS
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    action VARCHAR(64) NOT NULL,
    entity VARCHAR(64) NOT NULL,
    details_json TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
