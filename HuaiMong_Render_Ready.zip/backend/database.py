import sqlite3
import json
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'huaimong.db')
GEOJSON_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'huaimong_assets.geojson')

def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    c = conn.cursor()
    
    # 1. Assets table
    c.execute('''
    CREATE TABLE IF NOT EXISTS assets (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        folder_path TEXT,
        category_code TEXT NOT NULL,
        category_label TEXT NOT NULL,
        criticality TEXT DEFAULT 'STANDARD',
        length_km REAL,
        area_rai REAL,
        geometry_geojson TEXT,
        status_operation TEXT DEFAULT 'รอข้อมูล',
        status_inspection TEXT DEFAULT 'รอข้อมูล',
        condition_score TEXT DEFAULT 'รอข้อมูล',
        water_elevation_msl TEXT DEFAULT 'รอข้อมูล',
        discharge_m3_s TEXT DEFAULT 'รอข้อมูล',
        design_capacity TEXT DEFAULT 'รอข้อมูล',
        responsible_unit TEXT DEFAULT 'ฝ่ายจัดสรรน้ำและปรับปรุงระบบชลประทาน ห้วยโมง',
        data_lineage TEXT DEFAULT 'KML / GeoJSON Official Import',
        created_at TEXT,
        updated_at TEXT
    )
    ''')

    # 2. Water Telemetry
    c.execute('''
    CREATE TABLE IF NOT EXISTS water_telemetry (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_id TEXT NOT NULL,
        station_name TEXT NOT NULL,
        recorded_at TEXT NOT NULL,
        water_level_upstream_msl REAL,
        water_level_downstream_msl REAL,
        discharge_m3_s REAL,
        gate_opening_m REAL,
        active_pumps INTEGER DEFAULT 0,
        pump_capacity_total_m3_s REAL,
        status TEXT DEFAULT 'ปกติ',
        data_source TEXT DEFAULT 'สถานีโทรมาตร ชป. ห้วยโมง (DEMO - รอเชื่อมต่อ API ทางการ)'
    )
    ''')

    # 3. Irrigation Zones
    c.execute('''
    CREATE TABLE IF NOT EXISTS irrigation_zones (
        id TEXT PRIMARY KEY,
        zone_code TEXT NOT NULL,
        zone_name TEXT NOT NULL,
        station_ref TEXT,
        target_area_rai REAL DEFAULT 0.0,
        actual_irrigated_rai REAL DEFAULT 0.0,
        crop_type TEXT DEFAULT 'ข้าวนาปรัง / ข้าวโพด',
        farmer_count INTEGER DEFAULT 0,
        water_demand_m3 REAL DEFAULT 0.0,
        water_delivered_m3 REAL DEFAULT 0.0,
        rotational_schedule TEXT DEFAULT 'ตามรอบเวรการส่งน้ำ ชป.',
        equity_index REAL DEFAULT 1.0,
        complaint_count INTEGER DEFAULT 0,
        resolved_count INTEGER DEFAULT 0,
        status TEXT DEFAULT 'ปกติ'
    )
    ''')

    # 4. Hydrological Monitoring
    c.execute('''
    CREATE TABLE IF NOT EXISTS hydrological_monitoring (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_code TEXT NOT NULL,
        station_name TEXT NOT NULL,
        recorded_at TEXT NOT NULL,
        rainfall_24h_mm REAL DEFAULT 0.0,
        water_level_msl REAL,
        warning_level_msl REAL,
        critical_level_msl REAL,
        mekong_level_msl REAL,
        trend TEXT DEFAULT 'ทรงตัว',
        risk_level TEXT DEFAULT 'ปกติ',
        status_note TEXT
    )
    ''')

    # 5. Asset Inspections
    c.execute('''
    CREATE TABLE IF NOT EXISTS asset_inspections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_id TEXT NOT NULL,
        inspection_date TEXT NOT NULL,
        inspector_name TEXT NOT NULL,
        condition_rating INTEGER,
        condition_description TEXT,
        defects_found TEXT,
        urgent_repair_needed INTEGER DEFAULT 0,
        estimated_repair_cost_thb REAL DEFAULT 0.0,
        maintenance_status TEXT DEFAULT 'รอการจัดสรรงบ',
        FOREIGN KEY(asset_id) REFERENCES assets(id)
    )
    ''')

    # 6. Budget & Projects
    c.execute('''
    CREATE TABLE IF NOT EXISTS budget_projects (
        id TEXT PRIMARY KEY,
        project_name TEXT NOT NULL,
        fiscal_year_be INTEGER NOT NULL,
        budget_category TEXT NOT NULL,
        allocated_thb REAL NOT NULL,
        disbursed_thb REAL DEFAULT 0.0,
        physical_progress_percent REAL DEFAULT 0.0,
        contractor TEXT,
        contract_end_date TEXT,
        risk_level TEXT DEFAULT 'ต่ำ',
        beneficiary_households INTEGER DEFAULT 0,
        beneficiary_area_rai REAL DEFAULT 0.0
    )
    ''')

    # 7. Strategic KPIs
    c.execute('''
    CREATE TABLE IF NOT EXISTS strategic_kpis (
        id TEXT PRIMARY KEY,
        kpi_code TEXT NOT NULL,
        kpi_name TEXT NOT NULL,
        category TEXT NOT NULL,
        formula_expression TEXT NOT NULL,
        unit TEXT NOT NULL,
        data_owner TEXT NOT NULL,
        frequency TEXT NOT NULL,
        official_reference TEXT NOT NULL,
        is_official_verified INTEGER DEFAULT 0,
        target_value REAL,
        actual_value REAL,
        achievement_percent REAL,
        status TEXT DEFAULT 'รอข้อมูล'
    )
    ''')

    # 8. Command Incidents
    c.execute('''
    CREATE TABLE IF NOT EXISTS command_incidents (
        id TEXT PRIMARY KEY,
        incident_title TEXT NOT NULL,
        category TEXT NOT NULL,
        severity TEXT NOT NULL,
        location_description TEXT,
        asset_id TEXT,
        reported_at TEXT,
        due_date TEXT,
        assigned_officer TEXT,
        assigned_department TEXT,
        executive_directive TEXT,
        action_taken TEXT,
        evidence_url TEXT,
        status TEXT DEFAULT 'ค้างดำเนินการ',
        closed_at TEXT
    )
    ''')

    # 9. Audit Logs
    c.execute('''
    CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        user_id TEXT,
        action TEXT,
        entity TEXT,
        details_json TEXT,
        ip_address TEXT
    )
    ''')

    conn.commit()

    # Check if assets need loading
    c.execute('SELECT COUNT(*) FROM assets')
    count = c.fetchone()[0]
    if count == 0 and os.path.exists(GEOJSON_PATH):
        load_kml_geojson(conn)
        
    seed_reference_and_demo_data(conn)
    conn.close()
    print("Database initialization complete.")

def load_kml_geojson(conn):
    print("Seeding assets table from huaimong_assets.geojson...")
    with open(GEOJSON_PATH, 'r', encoding='utf-8') as f:
        data = json.load(f)
        
    c = conn.cursor()
    now = datetime.now().isoformat()
    rows = []
    for feat in data.get('features', []):
        p = feat['properties']
        geom = json.dumps(feat['geometry'], ensure_ascii=False)
        rows.append((
            p['id'],
            p['name'],
            p['folder_path'],
            p['category_code'],
            p['category_label'],
            p.get('criticality', 'STANDARD'),
            p.get('length_km'),
            p.get('area_rai'),
            geom,
            p.get('status_operation', 'รอข้อมูล'),
            p.get('status_inspection', 'รอข้อมูล'),
            p.get('condition_score', 'รอข้อมูล'),
            p.get('water_elevation_msl', 'รอข้อมูล'),
            p.get('discharge_m3_s', 'รอข้อมูล'),
            p.get('design_capacity', 'รอข้อมูล'),
            p.get('responsible_unit', 'ฝ่ายจัดสรรน้ำและปรับปรุงระบบชลประทาน ห้วยโมง'),
            p.get('data_lineage', 'KML Official Import'),
            now,
            now
        ))
        
    c.executemany('''
    INSERT OR REPLACE INTO assets VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ''', rows)
    conn.commit()
    print(f"Loaded {len(rows)} spatial assets into database.")

def seed_reference_and_demo_data(conn):
    c = conn.cursor()
    
    # 1. Telemetry Stations (Regulator + P1 to P10)
    c.execute('SELECT COUNT(*) FROM water_telemetry')
    if c.fetchone()[0] == 0:
        telemetry_samples = [
            ("REG-01", "ปตร.ปากห้วยโมง (อาคารควบคุม)", "2569-10-19 11:00:00", 168.20, 166.50, 45.5, 1.80, 0, 0.0, "เปิดระบายน้ำ", "สถานีโทรมาตร ชป. ปตร.ปากห้วยโมง [DEMO ติดป้ายทดสอบ]"),
            ("ST-P01", "สถานีสูบน้ำด้วยไฟฟ้า P1 (ห้วยโมง)", "2569-10-19 11:00:00", 167.80, 167.10, 8.2, 0.0, 3, 12.0, "กำลังสูบส่งน้ำ", "ระบบควบคุม SCADA สถานี P1 [DEMO ติดป้ายทดสอบ]"),
            ("ST-P03", "สถานีสูบน้ำด้วยไฟฟ้า P3", "2569-10-19 11:00:00", 167.60, 166.90, 6.5, 0.0, 2, 8.0, "กำลังสูบส่งน้ำ", "ระบบควบคุม SCADA สถานี P3 [DEMO ติดป้ายทดสอบ]"),
            ("ST-P04", "สถานีสูบน้ำด้วยไฟฟ้า P4", "2569-10-19 11:00:00", 167.40, 166.80, 5.0, 0.0, 2, 8.0, "กำลังสูบส่งน้ำ", "ระบบควบคุม SCADA สถานี P4 [DEMO ติดป้ายทดสอบ]"),
            ("ST-P05", "สถานีสูบน้ำด้วยไฟฟ้า P5", "2569-10-19 11:00:00", 167.30, 166.70, 4.2, 0.0, 1, 4.0, "กำลังสูบส่งน้ำ", "ระบบควบคุม SCADA สถานี P5 [DEMO ติดป้ายทดสอบ]"),
            ("ST-P06", "สถานีสูบน้ำด้วยไฟฟ้า P6", "2569-10-19 11:00:00", 167.10, 166.50, 7.8, 0.0, 2, 8.0, "กำลังสูบส่งน้ำ", "ระบบควบคุม SCADA สถานี P6 [DEMO ติดป้ายทดสอบ]"),
            ("ST-P07", "สถานีสูบน้ำด้วยไฟฟ้า P7", "2569-10-19 11:00:00", 167.00, 166.40, 6.0, 0.0, 2, 8.0, "กำลังสูบส่งน้ำ", "ระบบควบคุม SCADA สถานี P7 [DEMO ติดป้ายทดสอบ]"),
            ("ST-P08", "สถานีสูบน้ำด้วยไฟฟ้า P8", "2569-10-19 11:00:00", 166.90, 166.30, 3.5, 0.0, 1, 4.0, "กำลังสูบส่งน้ำ", "ระบบควบคุม SCADA สถานี P8 [DEMO ติดป้ายทดสอบ]"),
            ("ST-P09", "สถานีสูบน้ำด้วยไฟฟ้า P9", "2569-10-19 11:00:00", 166.80, 166.20, 3.2, 0.0, 1, 4.0, "กำลังสูบส่งน้ำ", "ระบบควบคุม SCADA สถานี P9 [DEMO ติดป้ายทดสอบ]"),
            ("ST-P10", "สถานีสูบน้ำด้วยไฟฟ้า P10", "2569-10-19 11:00:00", 166.70, 166.10, 4.0, 0.0, 1, 4.0, "กำลังสูบส่งน้ำ", "ระบบควบคุม SCADA สถานี P10 [DEMO ติดป้ายทดสอบ]"),
        ]
        c.executemany('''
        INSERT INTO water_telemetry (station_id, station_name, recorded_at, water_level_upstream_msl, water_level_downstream_msl, discharge_m3_s, gate_opening_m, active_pumps, pump_capacity_total_m3_s, status, data_source)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
        ''', telemetry_samples)

    # 2. Irrigation Zones (Zone 1 - Zone 10 corresponding to P1-P10)
    c.execute('SELECT COUNT(*) FROM irrigation_zones')
    if c.fetchone()[0] == 0:
        zones = [
            ("Z-01", "ZONE-01", "โซน 1 (พื้นที่ P1)", "ST-P01", 8500.0, 8100.0, "ข้าวนาปรัง", 420, 4250000.0, 4050000.0, "รอบที่ 2 (จันทร์-พุธ)", 0.95, 2, 2, "ปกติ"),
            ("Z-03", "ZONE-03", "โซน 3 (พื้นที่ P3)", "ST-P03", 6200.0, 5800.0, "ข้าวนาปรัง / พืชผัก", 310, 3100000.0, 2900000.0, "รอบที่ 1 (พฤหัส-เสาร์)", 0.93, 1, 1, "ปกติ"),
            ("Z-04", "ZONE-04", "โซน 4 (พื้นที่ P4)", "ST-P04", 7800.0, 7500.0, "ข้าวนาปรัง", 390, 3900000.0, 3750000.0, "รอบที่ 2 (จันทร์-พุธ)", 0.96, 0, 0, "ปกติ"),
            ("Z-05", "ZONE-05", "โซน 5 (พื้นที่ P5)", "ST-P05", 5400.0, 5000.0, "พืชไร่ / ยาสูบ", 270, 2400000.0, 2250000.0, "รอบที่ 1 (พฤหัส-เสาร์)", 0.92, 3, 2, "เฝ้าระวังปลายคลอง"),
            ("Z-06", "ZONE-06", "โซน 6 (พื้นที่ P6)", "ST-P06", 9200.0, 8900.0, "ข้าวนาปรัง", 480, 4600000.0, 4450000.0, "รอบที่ 2 (จันทร์-พุธ)", 0.97, 1, 1, "ปกติ"),
            ("Z-07", "ZONE-07", "โซน 7 (พื้นที่ P7)", "ST-P07", 7100.0, 6800.0, "ข้าวนาปรัง", 360, 3550000.0, 3400000.0, "รอบที่ 1 (พฤหัส-เสาร์)", 0.95, 0, 0, "ปกติ"),
            ("Z-08", "ZONE-08", "โซน 8 (พื้นที่ P8)", "ST-P08", 4300.0, 3900.0, "พืชผัก / ไม้ผล", 215, 1950000.0, 1750000.0, "รอบที่ 2 (จันทร์-พุธ)", 0.90, 2, 2, "ปกติ"),
            ("Z-09", "ZONE-09", "โซน 9 (พื้นที่ P9)", "ST-P09", 5100.0, 4700.0, "ข้าวนาปรัง", 255, 2550000.0, 2350000.0, "รอบที่ 1 (พฤหัส-เสาร์)", 0.92, 1, 1, "ปกติ"),
            ("Z-10", "ZONE-10", "โซน 10 (พื้นที่ P10)", "ST-P10", 6400.0, 5900.0, "ข้าวนาปรัง", 320, 3200000.0, 2950000.0, "รอบที่ 2 (จันทร์-พุธ)", 0.91, 1, 0, "เฝ้าระวังปลายคลอง"),
        ]
        c.executemany('''
        INSERT INTO irrigation_zones (id, zone_code, zone_name, station_ref, target_area_rai, actual_irrigated_rai, crop_type, farmer_count, water_demand_m3, water_delivered_m3, rotational_schedule, equity_index, complaint_count, resolved_count, status)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ''', zones)

    # 3. Hydrological Monitoring (Kh.18 and Mekong River Nong Khai)
    c.execute('SELECT COUNT(*) FROM hydrological_monitoring')
    if c.fetchone()[0] == 0:
        hydro_records = [
            ("KH-18", "สถานีวัดน้ำท่า Kh.18 ลำห้วยโมง", "2569-10-19 11:00:00", 12.5, 168.20, 169.50, 171.00, 164.80, "ทรงตัว", "ปกติ", "ระดับน้ำต่ำกว่าตลิ่ง 2.80 เมตร สภาพการไหลปกติ [DEMO]"),
            ("MEKONG-NK", "สถานีแม่น้ำโขง อำเภอเมืองหนองคาย (ชป./MRC)", "2569-10-19 11:00:00", 8.0, 9.85, 11.50, 12.20, 9.85, "ลดลง", "ปกติ", "ระดับน้ำโขงต่ำกว่าจุดวิกฤต 2.35 เมตร สามารถเปิดบานระบายน้ำลงน้ำโขงได้โดยไม่ต้องสูบ [DEMO]"),
            ("RES-HM", "อ่างเก็บน้ำห้วยโมง (จุดควบคุมน้ำต้นทุน)", "2569-10-19 11:00:00", 14.0, 172.50, 174.00, 175.50, None, "ทรงตัว", "ปกติ", "ปริมาตรเก็บกัก 82.4 ล้าน ลบ.ม. (78.5% ของความจุ) [DEMO]"),
        ]
        c.executemany('''
        INSERT INTO hydrological_monitoring (station_code, station_name, recorded_at, rainfall_24h_mm, water_level_msl, warning_level_msl, critical_level_msl, mekong_level_msl, trend, risk_level, status_note)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
        ''', hydro_records)

    # 4. Strategic KPIs (Aligning with RID, 20-Year Master Plan, Nong Khai Plan)
    c.execute('SELECT COUNT(*) FROM strategic_kpis')
    if c.fetchone()[0] == 0:
        kpis = [
            ("K-01", "KPI-01", "ร้อยละพื้นที่ได้รับน้ำตามแผน", "การบริการส่งน้ำ", "พื้นที่ได้รับน้ำจริง / พื้นที่เป้าหมาย × 100", "ร้อยละ", "ฝ่ายจัดสรรน้ำและปรับปรุงระบบชลประทาน", "รายสัปดาห์ / ฤดูกาล", "แผนปฏิบัติการจัดสรรน้ำฤดูแล้ง กรมชลประทาน พ.ศ. 2569", 0, 100.0, 94.67, 94.67, "ผ่านเกณฑ์ตามแผน (ข้อเสนอจนกว่ารับรอง)"),
            ("K-02", "KPI-02", "ร้อยละส่งน้ำตามแผน", "การบริหารจัดการน้ำ", "ปริมาตรส่งน้ำจริง / ปริมาตรตามแผน × 100", "ร้อยละ", "ฝ่ายจัดสรรน้ำฯ ห้วยโมง", "รายสัปดาห์", "เกณฑ์บริหารจัดการน้ำต้นทุน กรมชลประทาน", 0, 100.0, 94.38, 94.38, "ปกติ (ข้อเสนอจนกว่ารับรอง)"),
            ("K-03", "KPI-03", "ร้อยละอาคารตรวจสภาพแล้ว", "การบำรุงรักษาและสินทรัพย์", "อาคารตรวจแล้ว / อาคารครบกำหนดตรวจ × 100", "ร้อยละ", "ฝ่ายช่างกลและฝ่ายส่งน้ำฯ", "รายเดือน", "ระเบียบการตรวจสภาพเขื่อนและอาคารชลประทาน พ.ศ. 2566", 0, 100.0, 87.50, 87.50, "กำลังดำเนินการ (ข้อเสนอจนกว่ารับรอง)"),
            ("K-04", "KPI-04", "ร้อยละงานซ่อมเสร็จตามแผน", "งบประมาณและงานซ่อม", "งานซ่อมเสร็จ / งานถึงกำหนดแล้วเสร็จ × 100", "ร้อยละ", "ฝ่ายซ่อมบำรุงและวิศวกรรม", "รายเดือน", "แผนปรับปรุงซ่อมแซมระบบชลประทานประจำปีงบประมาณ", 0, 100.0, 83.33, 83.33, "ตามแผนงาน (ข้อเสนอจนกว่ารับรอง)"),
            ("K-05", "KPI-05", "ร้อยละเบิกจ่ายงบประมาณ", "ยุทธศาสตร์และการคลัง", "เบิกจ่ายสะสม / งบจัดสรร × 100", "ร้อยละ", "งานการเงินและบัญชี", "รายเดือน", "มาตรการเร่งรัดการเบิกจ่ายงบประมาณภาครัฐ ปี พ.ศ. 2569", 0, 80.0, 71.40, 89.25, "ตามเกณฑ์ไตรมาส (ข้อเสนอจนกว่ารับรอง)"),
            ("K-06", "KPI-06", "ระยะเวลาเฉลี่ยตอบสนองเหตุการณ์ฉุกเฉิน", "ศูนย์บัญชาการ", "ผลรวมเวลาตอบสนอง / จำนวนเหตุการณ์", "ชั่วโมง", "ศูนย์ปฏิบัติการน้ำอัจฉริยะ (SWOC ห้วยโมง)", "ต่อเนื่องเมื่อมีเหตุ", "คู่มือเผชิญเหตุอุทกภัยและภัยแล้ง กองอำนวยการน้ำแห่งชาติ (กอนช.)", 0, 4.0, 2.40, 100.0, "ผ่านเกณฑ์ดีมาก (ข้อเสนอจนกว่ารับรอง)"),
            ("K-07", "KPI-07", "ดัชนีความเท่าเทียมการส่งน้ำ (Equity Index)", "การบริการเกษตรกร", "อัตราส่งน้ำปลายคลอง / อัตราส่งน้ำต้นคลอง", "ดัชนี (1.0 = สูงสุด)", "ฝ่ายจัดสรรน้ำฯ", "รายรอบเวร", "เกณฑ์มาตรฐานระบบชลประทานท่อและคลองดาด กรมชลประทาน", 0, 0.90, 0.94, 104.4, "อยู่ในเกณฑ์ดี (ข้อเสนอจนกว่ารับรอง)")
        ]
        c.executemany('''
        INSERT INTO strategic_kpis (id, kpi_code, kpi_name, category, formula_expression, unit, data_owner, frequency, official_reference, is_official_verified, target_value, actual_value, achievement_percent, status)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ''', kpis)

    # 5. Budget Projects
    c.execute('SELECT COUNT(*) FROM budget_projects')
    if c.fetchone()[0] == 0:
        projects = [
            ("PRJ-2569-01", "โครงการเพิ่มประสิทธิภาพสถานีสูบน้ำด้วยไฟฟ้า P1-P4 ห้วยโมง", 2569, "งบลงทุนปรับปรุงระบบ", 14500000.0, 11200000.0, 82.0, "กิจการร่วมค้า ชป.หนองคายพัฒนา", "2569-12-31", "ต่ำ", 1850, 22500.0),
            ("PRJ-2569-02", "งานซ่อมแซมดาดคอนกรีตคลองส่งน้ำสายใหญ่ Mcanal ช่วง กม. 4+200 ถึง 7+800", 2569, "งบซ่อมบำรุงตามรอบ", 6800000.0, 4500000.0, 68.0, "หจก. ท่าบ่อวิศวกรรม", "2569-11-30", "ปานกลาง", 920, 12000.0),
            ("PRJ-2569-03", "งานติดตั้งเซนเซอร์วัดระดับน้ำโทรมาตรอัตโนมัติประจำ ปตร. และสถานีสูบ P5-P10", 2569, "งบพัฒนาดิจิทัลชลประทาน", 3200000.0, 2200000.0, 75.0, "บจก. สมาร์ทไฮโดรเทค", "2569-10-31", "ต่ำ", 2400, 31000.0),
            ("PRJ-2569-04", "งานกำจัดวัชพืชและสิ่งกีดขวางทางน้ำคลองระบาย Dcanal ต.กองนาง", 2569, "งบเตรียมการป้องกันอุทกภัย", 1200000.0, 1150000.0, 95.0, "ฝ่ายเครื่องจักรกล สำนักงานชลประทานที่ 5 จ.อุดรธานี", "2569-09-30", "ต่ำ", 650, 8500.0),
        ]
        c.executemany('''
        INSERT INTO budget_projects (id, project_name, fiscal_year_be, budget_category, allocated_thb, disbursed_thb, physical_progress_percent, contractor, contract_end_date, risk_level, beneficiary_households, beneficiary_area_rai)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        ''', projects)

    # 6. Command Center Incidents
    c.execute('SELECT COUNT(*) FROM command_incidents')
    if c.fetchone()[0] == 0:
        incidents = [
            ("INC-2569-001", "รายงานเกษตรกรปลายคลอง 5MC1 ได้รับน้ำไม่เพียงพอเนื่องจากวัชพืชอุดตันท่อลอด", "การจัดสรรน้ำ", "ปานกลาง", "คลอง 5MC1 กม. 2+450 ต.น้ำโมง อ.ท่าบ่อ", "HM-0412", "2569-10-18 14:30:00", "2569-10-20 18:00:00", "นายช่างชลประทานประจำโซน 5", "ฝ่ายส่งน้ำและบำรุงรักษา", "ให้ฝ่ายส่งน้ำส่งหน่วยเคลื่อนที่เร็วเข้าเคลียร์วัชพืชและเร่งการส่งน้ำตามรอบเวรให้ถึงแปลงปลายคลองภายใน 24 ชม.", "ส่งเครื่องจักรเข้ากำจัดวัชพืชแล้ว กำลังระบายน้ำเข้าแปลง", "https://rid.go.th/huaimong/evidence-001.jpg", "กำลังแก้ไข", None),
            ("INC-2569-002", "ตรวจพบการรั่วซึมบริเวณฐานคันกั้นน้ำ Dike 2 ช่วง กม. 1+100", "ความมั่นคงแข็งแรงของอาคาร", "สูง", "คันกั้นน้ำห้วยโมง Dike 2", "HM-0002", "2569-10-17 09:15:00", "2569-10-19 17:00:00", "วิศวกรโยธาประจำโครงการ", "ฝ่ายวิศวกรรม", "ตรวจสอบการรั่วซึม (Seepage) พร้อมนำกระสอบทรายเข้าเสริมแนวคันกั้นน้ำชั่วคราว และประเมินความปลอดภัยของเขื่อน", "เสริมคันดินและกระสอบทรายเรียบร้อย ไม่พบการเคลื่อนตัวของโครงสร้าง", "https://rid.go.th/huaimong/evidence-002.jpg", "รอตรวจรับ", None),
            ("INC-2569-003", "เตรียมความพร้อมบานระบายน้ำ ปตร.ปากห้วยโมง รองรับฝนตกสะสมเหนือลุ่มน้ำ", "บริหารจัดการน้ำอุทกภัย", "วิกฤต", "ปตร.ปากห้วยโมง ต.เวียงคุก", "HM-0016", "2569-10-19 08:00:00", "2569-10-19 16:00:00", "หัวหน้าฝ่ายจัดสรรน้ำฯ", "ฝ่ายส่งน้ำและช่างกล", "เปิดบานระบายเพิ่มขึ้น 0.50 เมตร เพื่อพร่องน้ำล่วงหน้า และเฝ้าระวังระดับน้ำโขงหนองคายทุกชั่วโมง", "ยกบานระบายขึ้น 1.80 เมตร ระบายน้ำออกสู่แม่น้ำโขงตามเกณฑ์ควบคุม", "https://rid.go.th/huaimong/evidence-003.jpg", "ปิดงาน", "2569-10-19 10:30:00")
        ]
        c.executemany('''
        INSERT INTO command_incidents (id, incident_title, category, severity, location_description, asset_id, reported_at, due_date, assigned_officer, assigned_department, executive_directive, action_taken, evidence_url, status, closed_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ''', incidents)

    conn.commit()

if __name__ == '__main__':
    init_db()
