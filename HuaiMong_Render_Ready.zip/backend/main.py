import os
import json
import sqlite3
import io
from datetime import datetime
from typing import Optional, List
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import xlsxwriter
import pptx
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from database import get_connection, init_db, DB_PATH
except ImportError:
    from backend.database import get_connection, init_db, DB_PATH

app = FastAPI(
    title="HUAI MONG SMART WATER COMMAND CENTER API",
    description="Executive Decision Support System API สำหรับโครงการส่งน้ำและบำรุงรักษาห้วยโมง จ.หนองคาย สำนักงานชลประทานที่ 5 จ.อุดรธานี กรมชลประทาน",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def detect_category(filename, props, geom_type):
    fn_lower = filename.lower()
    props_str = json.dumps(props, ensure_ascii=False).lower()
    
    # Priority 1: Subdistrict (Tambon) - Must be checked before district
    if any(k in props for k in ['tam_code', 'tam_th', 'tam_en', 'tambon']) or 'tambon' in fn_lower or 'subdistrict' in fn_lower or 'ตำบล' in fn_lower:
        return 'subdistrict_boundary', 'ขอบเขตตำบล (Subdistrict Boundary)', 'REFERENCE'
    elif any(k in props for k in ['amp_code', 'amp_th', 'amp_en', 'amphoe']) or 'district' in fn_lower or 'อำเภอ' in fn_lower:
        return 'district_boundary', 'ขอบเขตอำเภอ (District Boundary)', 'REFERENCE'
    elif any(k in props for k in ['pro_code', 'pro_th', 'pro_en', 'province', 'changwat']) or 'province' in fn_lower or 'จังหวัด' in fn_lower:
        return 'province_boundary', 'ขอบเขตจังหวัด (Province Boundary)', 'REFERENCE'
    elif 'subbasin' in fn_lower or 'ลุ่มน้ำสาขา' in fn_lower or 'sub_basin' in fn_lower:
        return 'subbasin_boundary', 'ขอบเขตลุ่มน้ำสาขา (Sub-Basin Boundary)', 'MAJOR'
    elif 'basin' in fn_lower or 'ลุ่มน้ำ' in fn_lower or 'watershed' in fn_lower:
        return 'basin_boundary', 'ขอบเขตลุ่มน้ำ (Basin Boundary)', 'MAJOR'
    elif 'ป่าสงวน' in fn_lower or 'สงวน' in fn_lower or 'nrf' in fn_lower or 'fr_name' in props or 'reserved_forest' in fn_lower:
        return 'national_reserved_forest', 'ขอบเขตป่าสงวนแห่งชาติ (National Reserved Forest)', 'REFERENCE'
    elif 'ป่าไม้ถาวร' in fn_lower or 'ถาวร' in fn_lower or 'pmfc' in props or 'permanent_forest' in fn_lower:
        return 'permanent_forest', 'ขอบเขตป่าไม้ถาวร (Permanent Forest)', 'REFERENCE'
    elif 'forest' in fn_lower or 'ป่า' in fn_lower or 'อุทยาน' in fn_lower or 'mnre' in fn_lower:
        return 'forest_boundary', 'ขอบเขตป่าไม้/พื้นที่อนุรักษ์ (Forest Boundary)', 'REFERENCE'
    elif 'flood' in fn_lower or 'น้ำท่วม' in fn_lower or 'inundation' in fn_lower or 'risk' in fn_lower or 'เสี่ยงภัย' in fn_lower:
        return 'flood_risk_area', 'พื้นที่เสี่ยงภัยอุทกภัย/น้ำท่วม', 'CRITICAL'
    elif 'drought' in fn_lower or 'แล้ง' in fn_lower:
        return 'drought_risk_area', 'พื้นที่เสี่ยงภัยแล้ง', 'CRITICAL'
    elif 'cadastral' in fn_lower or 'parcel' in fn_lower or 'แปลงที่ดิน' in fn_lower:
        return 'cadastral_boundary', 'แนวเขตที่ดิน/หลักเขตชลประทาน', 'REFERENCE'
    elif 'zone' in fn_lower or 'โซน' in fn_lower:
        return 'irrigation_zone', 'พื้นที่โซนชลประทาน (Zone)', 'STANDARD'
    elif any(k in props for k in ['str_name_t', 'str_name_e']) or 'waterbody' in fn_lower or 'แหล่งน้ำ' in fn_lower or 'water_resource' in fn_lower or 'stream' in fn_lower or 'river' in fn_lower:
        return 'water_resource', 'แหล่งน้ำ / ลำน้ำธรรมชาติ (Water Resources)', 'STANDARD'
    elif 'moo' in props_str or 'village' in props_str or 'หมู่บ้าน' in props_str:
        return 'village_point', 'จุดที่ตั้งหมู่บ้าน (Village)', 'STANDARD'
    elif 'canal' in fn_lower or 'คลอง' in fn_lower:
        return 'main_canal', 'คลองส่งน้ำชลประทาน', 'STANDARD'
    elif 'dike' in fn_lower or 'คัน' in fn_lower:
        return 'dike', 'คันกั้นน้ำชลประทาน', 'CRITICAL'
    elif 'polygon' in geom_type.lower():
        # Derive human friendly label from filename if available
        base_title = os.path.splitext(filename)[0].replace("uploaded_", "").replace("_", " ")
        return 'custom_boundary', f"ขอบเขตพื้นที่ ({base_title})", 'STANDARD'
    elif 'line' in geom_type.lower():
        base_title = os.path.splitext(filename)[0].replace("uploaded_", "").replace("_", " ")
        return 'custom_line', f"แนวเส้นโครงข่าย ({base_title})", 'STANDARD'
    else:
        base_title = os.path.splitext(filename)[0].replace("uploaded_", "").replace("_", " ")
        return 'custom_point', f"จุดพิกัดตำแหน่ง ({base_title})", 'STANDARD'

def extract_name(props, category_code, index):
    if category_code in ('forest_boundary', 'national_reserved_forest', 'permanent_forest'):
        if 'fr_name' in props and props['fr_name']:
            nm_str = str(props['fr_name']).strip()
            prefix = "ป่าสงวนฯ " if not nm_str.startswith("ป่า") and not nm_str.startswith("เขต") else ""
            return f"{prefix}{nm_str}".strip()
        nm = props.get('name') or props.get('NAME') or props.get('title') or props.get('pmfc') or props.get('fr_name')
        if nm:
            nm_str = str(nm).strip()
            prefix = "ป่า" if not nm_str.startswith("ป่า") and not nm_str.startswith("เขต") else ""
            return f"{prefix}{nm_str}".strip()
    elif category_code == 'subdistrict_boundary':
        tam_th = props.get('tam_th') or props.get('tam_en') or props.get('name') or props.get('NAME')
        amp_th = props.get('amp_th') or props.get('amp_en') or ''
        pro_th = props.get('pro_th') or props.get('pro_en') or ''
        if tam_th:
            prefix_tam = "ตำบล" if not tam_th.startswith("ตำบล") and not tam_th.startswith("ต.") else ""
            amp_clean = amp_th.replace("อำเภอ", "").replace("อ.", "").strip()
            amp_str = f" อ.{amp_clean}" if amp_clean else ""
            pro_clean = pro_th.replace("จังหวัด", "").replace("จ.", "").strip()
            pro_str = f" จ.{pro_clean}" if pro_clean else ""
            return f"{prefix_tam}{tam_th}{amp_str}{pro_str}".strip()
    elif category_code == 'district_boundary':
        amp_th = props.get('amp_th') or props.get('amp_en') or props.get('name') or props.get('NAME')
        pro_th = props.get('pro_th') or props.get('pro_en') or ''
        if amp_th:
            prefix = "อำเภอ" if not amp_th.startswith("อำเภอ") and not amp_th.startswith("อ.") else ""
            pro_clean = pro_th.replace("จังหวัด", "").replace("จ.", "").strip()
            pro_str = f" จ.{pro_clean}" if pro_clean else ""
            return f"{prefix}{amp_th}{pro_str}".strip()
    elif category_code == 'province_boundary':
        pro_th = props.get('pro_th') or props.get('pro_en') or props.get('name') or props.get('NAME')
        if pro_th:
            prefix = "จังหวัด" if not pro_th.startswith("จังหวัด") and not pro_th.startswith("จ.") else ""
            return f"{prefix}{pro_th}".strip()
    elif category_code == 'water_resource':
        name_t = props.get('str_name_t')
        name_e = props.get('str_name_e')
        ptype = props.get('ptype')
        
        ptype_map = {
            1: "แม่น้ำธรรมชาติ",
            2: "ลำห้วย/ลำน้ำธรรมชาติ",
            3: "หนอง/บึงธรรมชาติ",
            4: "อ่างเก็บน้ำ",
            5: "แหล่งน้ำ/สระน้ำ"
        }
        type_desc = ptype_map.get(ptype, "แหล่งน้ำธรรมชาติ")
        
        if name_t and str(name_t).strip() and str(name_t).strip().lower() != 'none':
            clean_t = str(name_t).strip()
            if name_e and str(name_e).strip() and str(name_e).strip().lower() != 'none':
                return f"{clean_t} ({str(name_e).strip()})"
            return clean_t
        elif name_e and str(name_e).strip() and str(name_e).strip().lower() != 'none':
            return f"{type_desc} ({str(name_e).strip()})"
        else:
            return f"{type_desc} #{index+1}"
            
    for k in ['str_name_t', 'name', 'NAME', 'Name', 'title', 'Title', 'tam_th', 'amp_th', 'pro_th', 'str_name_e', 'description']:
        if k in props and props[k]:
            return str(props[k]).strip()
            
    return f"องค์ประกอบนำเข้า #{index+1}"

def ingest_file_into_assets(filepath: str, conn):
    filename = os.path.basename(filepath)
    ext = os.path.splitext(filename)[1].lower()
    now = datetime.now().isoformat()
    c = conn.cursor()
    ingested_count = 0
    primary_cat_code = 'custom_boundary'
    primary_cat_label = 'ขอบเขตพื้นที่เชิงพื้นที่'
    
    if ext in ('.geojson', '.json'):
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        for i, feat in enumerate(data.get('features', [])):
            props = feat.get('properties', {})
            geom = feat.get('geometry', {})
            geom_type = geom.get('type', 'Unknown')
            
            cat_code, cat_label, criticality = detect_category(filename, props, geom_type)
            name = extract_name(props, cat_code, i)
            primary_cat_code = cat_code
            primary_cat_label = cat_label
            
            feat_id = None
            if 'tam_code' in props:
                feat_id = f"SUBDIST-{props['tam_code']}"
            elif 'amp_code' in props:
                feat_id = f"DIST-{props['amp_code']}"
            elif 'pro_code' in props:
                feat_id = f"PROV-{props['pro_code']}"
            elif 'id' in feat:
                feat_id = f"UP-{feat['id']}"
            elif 'id' in props:
                feat_id = f"UP-{props['id']}"
            else:
                clean_fn = "".join(ch for ch in filename if ch.isalnum())[:8]
                feat_id = f"UP-{clean_fn}-{i+1:04d}"
                
            area_rai = None
            if 'area_sqkm' in props and props['area_sqkm']:
                try:
                    area_rai = round(float(props['area_sqkm']) * 625.0, 2)
                except Exception:
                    pass
            elif 'area_rai' in props and props['area_rai']:
                try:
                    area_rai = round(float(props['area_rai']), 2)
                except Exception:
                    pass
                    
            c.execute('''
            INSERT OR REPLACE INTO assets (
                id, name, folder_path, category_code, category_label, criticality,
                length_km, area_rai, geometry_geojson, status_operation, status_inspection,
                condition_score, water_elevation_msl, discharge_m3_s, design_capacity,
                responsible_unit, data_lineage, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                feat_id,
                name,
                f"Uploaded/{filename}",
                cat_code,
                cat_label,
                criticality,
                props.get('perimeter'),
                area_rai,
                json.dumps(geom, ensure_ascii=False),
                'ขอบเขตการปกครอง/แผนที่ฐาน',
                'ตรวจสอบ CRS EPSG:4326 แล้ว',
                'ปกติ',
                '-',
                '-',
                '-',
                'กรมการปกครอง / ข้อมูลเชิงพื้นที่บูรณาการ',
                f"Uploaded: {filename}",
                now,
                now
            ))
            ingested_count += 1
            
    conn.commit()
    return ingested_count, primary_cat_code, primary_cat_label

def sync_data_directory():
    conn = get_connection()
    data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
    total_ingested = 0
    if os.path.exists(data_dir):
        for f in os.listdir(data_dir):
            ext = os.path.splitext(f)[1].lower()
            # Ingest any GeoJSON or JSON that starts with uploaded_ (only user uploaded files)
            if (f.startswith("uploaded_")) and ext in ('.geojson', '.json'):
                fp = os.path.join(data_dir, f)
                try:
                    cnt, _, _ = ingest_file_into_assets(fp, conn)
                    total_ingested += cnt
                except Exception as e:
                    print(f"Error auto-ingesting {f}: {e}")
    conn.close()
    return total_ingested

# Startup
@app.on_event("startup")
def startup_event():
    init_db()
    sync_data_directory()

@app.get("/api/gis/sync")
@app.post("/api/gis/sync")
def sync_gis_files():
    total = sync_data_directory()
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT category_code, category_label, COUNT(*) as count FROM assets GROUP BY category_code, category_label ORDER BY count DESC")
    cats = [dict(r) for r in c.fetchall()]
    c.execute("SELECT COUNT(*) FROM assets")
    total_assets = c.fetchone()[0]
    conn.close()
    return {
        "success": True,
        "message": f"ซิงค์ไฟล์ข้อมูลในโฟลเดอร์ data สำเร็จ รวมสินทรัพย์/ขอบเขตทั้งหมด {total_assets:,} รายการ",
        "total_assets": total_assets,
        "categories": cats
    }

# -------------------------------------------------------------
# 1. EXECUTIVE OVERVIEW API
# -------------------------------------------------------------
@app.get("/api/overview")
def get_executive_overview():
    conn = get_connection()
    c = conn.cursor()
    
    # Assets count
    c.execute("SELECT COUNT(*) FROM assets")
    total_assets = c.fetchone()[0]
    
    # Critical infrastructure count
    c.execute("SELECT COUNT(*) FROM assets WHERE criticality = 'CRITICAL'")
    critical_assets = c.fetchone()[0]
    
    # Telemetry aggregate
    c.execute("SELECT SUM(discharge_m3_s), SUM(active_pumps) FROM water_telemetry")
    row_tele = c.fetchone()
    total_discharge = round(row_tele[0] or 0.0, 2)
    active_pumps = row_tele[1] or 0
    
    # Irrigation zones aggregate
    c.execute("SELECT SUM(target_area_rai), SUM(actual_irrigated_rai), SUM(farmer_count), SUM(water_delivered_m3), AVG(equity_index) FROM irrigation_zones")
    row_zone = c.fetchone()
    target_area = round(row_zone[0] or 0.0, 2)
    actual_irrigated = round(row_zone[1] or 0.0, 2)
    farmer_count = row_zone[2] or 0
    water_delivered = round(row_zone[3] or 0.0, 2)
    avg_equity = round(row_zone[4] or 0.0, 3)
    irrigated_pct = round((actual_irrigated / target_area * 100.0), 2) if target_area > 0 else 0.0
    
    # Budget aggregate
    c.execute("SELECT SUM(allocated_thb), SUM(disbursed_thb) FROM budget_projects")
    row_bud = c.fetchone()
    allocated_thb = row_bud[0] or 0.0
    disbursed_thb = row_bud[1] or 0.0
    disbursed_pct = round((disbursed_thb / allocated_thb * 100.0), 2) if allocated_thb > 0 else 0.0
    
    # Incidents
    c.execute("SELECT COUNT(*) FROM command_incidents WHERE status != 'ปิดงาน'")
    pending_incidents = c.fetchone()[0]
    
    # Hydrology Kh.18 & Mekong
    c.execute("SELECT station_name, water_level_msl, warning_level_msl, critical_level_msl, risk_level, trend FROM hydrological_monitoring")
    hydro_summary = [dict(r) for r in c.fetchall()]
    
    conn.close()
    
    return {
        "project_name": "โครงการส่งน้ำและบำรุงรักษาห้วยโมง จ.หนองคาย สำนักงานชลประทานที่ 5 จ.อุดรธานี กรมชลประทาน",
        "current_fiscal_year_be": 2569,
        "as_of_time": datetime.now().strftime("%d/%m/2569 %H:%M น. (Asia/Bangkok)"),
        "kpi_summary": {
            "water_storage_status": "ปกติ (82.4 ล้าน ลบ.ม. / 78.5% ความจุ)",
            "total_discharge_m3_s": total_discharge,
            "active_pumps_units": active_pumps,
            "irrigation_delivery_percent": irrigated_pct,
            "target_area_rai": target_area,
            "actual_irrigated_rai": actual_irrigated,
            "farmer_beneficiaries": farmer_count,
            "water_delivered_m3": water_delivered,
            "equity_index": avg_equity,
            "budget_allocated_thb": allocated_thb,
            "budget_disbursed_thb": disbursed_thb,
            "budget_disbursed_percent": disbursed_pct,
            "total_gis_features": total_assets,
            "critical_assets_monitored": critical_assets,
            "pending_command_directives": pending_incidents
        },
        "risk_indicators": {
            "flood_risk": "ปกติ (ระดับน้ำโขง 9.85 ม.รทก. ต่ำกว่าตลิ่ง 2.35 ม.)",
            "drought_risk": "ต่ำ (น้ำต้นทุนในอ่างห้วยโมงเพียงพอตลอดฤดูส่งน้ำ)",
            "infrastructure_risk": "ปานกลาง (มีจุดเฝ้าระวังคันกั้นน้ำ Dike 2 และวัชพืชคลอง 5MC1)"
        },
        "hydrological_status": hydro_summary
    }

# -------------------------------------------------------------
# 2. GIS DIGITAL TWIN API
# -------------------------------------------------------------
@app.get("/api/gis/features")
def get_gis_features(category: Optional[str] = None, limit: int = 5000):
    conn = get_connection()
    c = conn.cursor()
    
    query = "SELECT id, name, folder_path, category_code, category_label, criticality, length_km, area_rai, geometry_geojson, status_operation, status_inspection, condition_score, water_elevation_msl, discharge_m3_s FROM assets"
    params = []
    
    if category and category != 'all':
        query += " WHERE category_code = ?"
        params.append(category)
        
    query += " LIMIT ?"
    params.append(limit)
    
    c.execute(query, params)
    rows = c.fetchall()
    conn.close()
    
    features = []
    for r in rows:
        geom = json.loads(r['geometry_geojson']) if r['geometry_geojson'] else None
        features.append({
            "type": "Feature",
            "id": r['id'],
            "geometry": geom,
            "properties": {
                "id": r['id'],
                "name": r['name'],
                "folder_path": r['folder_path'],
                "category_code": r['category_code'],
                "category_label": r['category_label'],
                "criticality": r['criticality'],
                "length_km": r['length_km'],
                "area_rai": r['area_rai'],
                "status_operation": r['status_operation'],
                "status_inspection": r['status_inspection'],
                "condition_score": r['condition_score'],
                "water_elevation_msl": r['water_elevation_msl'],
                "discharge_m3_s": r['discharge_m3_s']
            }
        })
        
    return {
        "type": "FeatureCollection",
        "metadata": {
            "total": len(features),
            "crs": "EPSG:4326 (WGS84)",
            "source": "Huai Mong GIS Digital Twin"
        },
        "features": features
    }

@app.get("/api/gis/categories")
def get_gis_categories():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT category_code, category_label, COUNT(*) as count FROM assets GROUP BY category_code, category_label ORDER BY count DESC")
    cats = [dict(r) for r in c.fetchall()]
    conn.close()
    return cats

@app.get("/api/gis/asset/{asset_id}")
def get_asset_detail(asset_id: str):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM assets WHERE id = ?", (asset_id,))
    row = c.fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="ไม่พบสินทรัพย์ที่ระบุ")
        
    c.execute("SELECT * FROM asset_inspections WHERE asset_id = ? ORDER BY inspection_date DESC", (asset_id,))
    inspections = [dict(r) for r in c.fetchall()]
    
    c.execute("SELECT * FROM command_incidents WHERE asset_id = ?", (asset_id,))
    incidents = [dict(r) for r in c.fetchall()]
    
    conn.close()
    res = dict(row)
    res['inspections'] = inspections
    res['incidents'] = incidents
    return res

class AssetUpdateRequest(BaseModel):
    name: Optional[str] = None
    category_code: Optional[str] = None
    criticality: Optional[str] = None
    status_operation: Optional[str] = None
    status_inspection: Optional[str] = None
    area_rai: Optional[float] = None
    length_km: Optional[float] = None
    responsible_unit: Optional[str] = None

@app.put("/api/gis/asset/{asset_id}")
def update_asset(asset_id: str, req: AssetUpdateRequest):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM assets WHERE id = ?", (asset_id,))
    row = c.fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="ไม่พบขอบเขตหรือสินทรัพย์ที่ระบุ")

    now = datetime.now().isoformat()
    # Build dynamic update fields
    fields = []
    params = []
    if req.name is not None:
        fields.append("name = ?")
        params.append(req.name.strip())
    if req.category_code is not None:
        fields.append("category_code = ?")
        params.append(req.category_code)
    if req.criticality is not None:
        fields.append("criticality = ?")
        params.append(req.criticality)
    if req.status_operation is not None:
        fields.append("status_operation = ?")
        params.append(req.status_operation)
    if req.status_inspection is not None:
        fields.append("status_inspection = ?")
        params.append(req.status_inspection)
    if req.area_rai is not None:
        fields.append("area_rai = ?")
        params.append(req.area_rai)
    if req.length_km is not None:
        fields.append("length_km = ?")
        params.append(req.length_km)
    if req.responsible_unit is not None:
        fields.append("responsible_unit = ?")
        params.append(req.responsible_unit)

    if fields:
        fields.append("updated_at = ?")
        params.append(now)
        params.append(asset_id)
        c.execute(f"UPDATE assets SET {', '.join(fields)} WHERE id = ?", params)
        conn.commit()

    conn.close()
    return {
        "success": True,
        "message": f"บันทึกข้อมูลสำเร็จ (รหัส: {asset_id})",
        "asset_id": asset_id
    }

@app.delete("/api/gis/asset/{asset_id}")
def delete_asset(asset_id: str):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT name, category_label FROM assets WHERE id = ?", (asset_id,))
    row = c.fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="ไม่พบขอบเขตหรือสินทรัพย์ที่ต้องการลบ")

    name = row[0] or asset_id
    cat_label = row[1] or ""
    c.execute("DELETE FROM assets WHERE id = ?", (asset_id,))
    # Clean up any related inspections or incidents if applicable
    c.execute("DELETE FROM asset_inspections WHERE asset_id = ?", (asset_id,))
    conn.commit()
    conn.close()

    return {
        "success": True,
        "message": f"ลบ '{name}' ({cat_label}) ออกจากระบบเรียบร้อยแล้ว",
        "asset_id": asset_id
    }

# -------------------------------------------------------------
# 3. WATER OPERATIONS API
# -------------------------------------------------------------
@app.get("/api/water-operations")
def get_water_operations():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM water_telemetry ORDER BY station_id ASC")
    stations = [dict(r) for r in c.fetchall()]
    
    # Calculate water balance
    total_discharge_m3_s = sum((s['discharge_m3_s'] or 0.0) for s in stations)
    daily_volume_million_m3 = round((total_discharge_m3_s * 86400.0) / 1000000.0, 3)
    loss_rate_percent = 8.5 # standard canal conveyance loss estimate for Huai Mong
    effective_delivered_volume = round(daily_volume_million_m3 * (1.0 - (loss_rate_percent / 100.0)), 3)
    
    conn.close()
    return {
        "as_of": datetime.now().strftime("%d/%m/2569 %H:%M น."),
        "summary": {
            "total_discharge_m3_s": round(total_discharge_m3_s, 2),
            "daily_volume_million_m3": daily_volume_million_m3,
            "estimated_conveyance_loss_pct": loss_rate_percent,
            "effective_delivered_volume_million_m3": effective_delivered_volume,
            "operating_pumps": sum(s['active_pumps'] for s in stations),
            "status_overall": "ปกติทุกสถานี"
        },
        "stations": stations
    }

# -------------------------------------------------------------
# 4. IRRIGATION SERVICE API
# -------------------------------------------------------------
@app.get("/api/irrigation-service")
def get_irrigation_service():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM irrigation_zones ORDER BY zone_code ASC")
    zones = [dict(r) for r in c.fetchall()]
    
    # Retrieve matching GIS polygon areas from assets
    c.execute("SELECT name, area_rai FROM assets WHERE category_code = 'irrigation_zone' AND geometry_geojson LIKE '%Polygon%'")
    gis_map = {r['name'].strip(): r['area_rai'] for r in c.fetchall()}
    
    for z in zones:
        z_num = z['zone_code'].replace('ZONE-', '').lstrip('0')
        gis_key = f"Zone_{z_num}"
        gis_area = gis_map.get(gis_key, 0.0)
        z['gis_boundary_area_rai'] = gis_area
        z['coverage_pct_gis'] = round((z['actual_irrigated_rai'] / gis_area * 100.0), 1) if gis_area > 0 else 0.0
    
    total_target = sum(z['target_area_rai'] for z in zones)
    total_actual = sum(z['actual_irrigated_rai'] for z in zones)
    total_gis = sum(z['gis_boundary_area_rai'] for z in zones)
    total_complaints = sum(z['complaint_count'] for z in zones)
    total_resolved = sum(z['resolved_count'] for z in zones)
    avg_equity = round(sum(z['equity_index'] for z in zones) / len(zones), 2) if zones else 1.0
    
    conn.close()
    return {
        "summary": {
            "total_target_area_rai": total_target,
            "total_actual_irrigated_rai": total_actual,
            "total_gis_boundary_rai": round(total_gis, 2),
            "achievement_rate_pct": round((total_actual / total_target * 100.0), 2) if total_target > 0 else 0.0,
            "overall_gis_coverage_pct": round((total_actual / total_gis * 100.0), 2) if total_gis > 0 else 0.0,
            "upstream_downstream_equity_index": avg_equity,
            "total_complaints": total_complaints,
            "resolved_complaints": total_resolved,
            "pending_complaints": total_complaints - total_resolved
        },
        "zones": zones
    }

def get_hydraulic_profile(delta_m: float = 0.0):
    stations = [
        {"id": "REG-01", "name": "ปตร.ปากห้วยโมง", "km": 0.5, "bed": 160.00, "current": 168.20, "warning": 169.50, "critical": 171.00, "delta_factor": 1.00},
        {"id": "ST-P01", "name": "สถานีสูบน้ำ P1", "km": 3.0, "bed": 160.80, "current": 167.80, "warning": 169.50, "critical": 170.80, "delta_factor": 0.95},
        {"id": "ST-P03", "name": "สถานีสูบน้ำ P3", "km": 6.5, "bed": 161.40, "current": 167.60, "warning": 169.60, "critical": 170.70, "delta_factor": 0.90},
        {"id": "ST-P04", "name": "สถานีสูบน้ำ P4", "km": 10.0, "bed": 162.00, "current": 167.40, "warning": 169.70, "critical": 170.60, "delta_factor": 0.85},
        {"id": "ST-P05", "name": "สถานีสูบน้ำ P5", "km": 13.5, "bed": 162.50, "current": 167.30, "warning": 169.80, "critical": 170.50, "delta_factor": 0.82},
        {"id": "ST-P06", "name": "สถานีสูบน้ำ P6", "km": 17.0, "bed": 163.00, "current": 167.10, "warning": 169.90, "critical": 170.40, "delta_factor": 0.80},
        {"id": "ST-P07", "name": "สถานีสูบน้ำ P7", "km": 20.5, "bed": 163.40, "current": 167.00, "warning": 170.00, "critical": 170.40, "delta_factor": 0.78},
        {"id": "ST-P08", "name": "สถานีสูบน้ำ P8", "km": 24.0, "bed": 163.80, "current": 166.90, "warning": 170.00, "critical": 170.50, "delta_factor": 0.75},
        {"id": "ST-P09", "name": "สถานีสูบน้ำ P9", "km": 27.5, "bed": 164.20, "current": 166.80, "warning": 170.10, "critical": 170.60, "delta_factor": 0.72},
        {"id": "ST-P10", "name": "สถานีสูบน้ำ P10", "km": 31.0, "bed": 164.50, "current": 166.70, "warning": 170.20, "critical": 170.70, "delta_factor": 0.70},
        {"id": "KH-18", "name": "สถานีวัดน้ำ Kh.18", "km": 36.5, "bed": 164.80, "current": 168.20, "warning": 169.50, "critical": 171.00, "delta_factor": 0.85},
        {"id": "RES-HM", "name": "อ่างเก็บน้ำห้วยโมง", "km": 48.0, "bed": 165.50, "current": 172.50, "warning": 174.00, "critical": 175.50, "delta_factor": 0.60},
    ]

    profile = []
    for s in stations:
        sim_val = round(s["current"] + (delta_m * s["delta_factor"]), 2)
        freeboard = round(s["critical"] - sim_val, 2)
        if sim_val >= s["critical"]:
            st = "วิกฤต (ล้นตลิ่ง)"
            st_color = "red"
        elif sim_val >= s["warning"]:
            st = "เฝ้าระวัง"
            st_color = "amber"
        else:
            st = "ปกติ"
            st_color = "emerald"

        profile.append({
            "station_id": s["id"],
            "station_name": s["name"],
            "distance_km": s["km"],
            "bed_level_msl": s["bed"],
            "current_water_level_msl": s["current"],
            "warning_level_msl": s["warning"],
            "critical_level_msl": s["critical"],
            "simulated_water_level_msl": sim_val,
            "freeboard_m": freeboard,
            "status": st,
            "status_color": st_color
        })
    return profile

# -------------------------------------------------------------
# 5. FLOOD & DROUGHT API + SCENARIO SIMULATOR
# -------------------------------------------------------------
@app.get("/api/flood-drought")
def get_flood_and_drought():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM hydrological_monitoring ORDER BY id ASC")
    stations = [dict(r) for r in c.fetchall()]
    conn.close()
    
    return {
        "as_of": datetime.now().strftime("%d/%m/2569 %H:%M น."),
        "warning_thresholds": {
            "kh18_warning_msl": 169.50,
            "kh18_critical_msl": 171.00,
            "mekong_warning_msl": 11.50,
            "mekong_critical_msl": 12.20
        },
        "mekong_status": "ระดับน้ำโขง 9.85 ม.รทก. สามารถระบายน้ำห้วยโมงลงสู่แม่น้ำโขงได้โดยแรงโน้มถ่วง (Gravity Flow)",
        "stations": stations,
        "water_profile": get_hydraulic_profile(0.0)
    }

class SimulationRequest(BaseModel):
    rainfall_added_mm: float = 50.0
    gate_opening_m: float = 1.80
    active_pumps: int = 5
    mekong_level_msl: float = 10.20

@app.post("/api/flood-drought/simulate")
def simulate_scenario(req: SimulationRequest):
    # Engineering hydraulic simulation approximation
    base_level = 168.20
    # Rainfall contribution: 100mm rain produces ~0.8m level rise in basin without drainage
    runoff_rise = (req.rainfall_added_mm / 100.0) * 0.85
    # Gate drainage capacity: 1m opening discharges approx 30 m3/s, reducing 0.35m level per 24h
    gate_reduction = req.gate_opening_m * 0.32
    # Pump capacity: each pump 4 m3/s reduces approx 0.05m level per 24h
    pump_reduction = req.active_pumps * 0.05
    # Mekong tailwater effect: if Mekong > 11.50, drainage efficiency drops
    tailwater_penalty = max(0.0, (req.mekong_level_msl - 11.0) * 0.25)
    
    simulated_level = round(base_level + runoff_rise - gate_reduction - pump_reduction + tailwater_penalty, 2)
    delta_m = round(simulated_level - base_level, 2)
    warning_msl = 169.50
    critical_msl = 171.00
    
    if simulated_level >= critical_msl:
        risk = "วิกฤต (น้ำล้นตลิ่งเข้าท่วมพื้นที่การเกษตรริมห้วยโมง)"
        action = "ต้องเดินเครื่องสูบน้ำสถานี P1-P10 เต็มกำลัง 100% พร้อมเปิดบาน ปตร. ปากห้วยโมง และแจ้งเตือน ปภ. จังหวัด"
    elif simulated_level >= warning_msl:
        risk = "เฝ้าระวัง (ระดับน้ำแตะระดับเตือนภัย)"
        action = "เสริมกระสอบทรายตามจุดต่ำสุดของคันกั้นน้ำ Dike 1-4 และเตรียมพร้อมเครื่องจักรกลสูบน้ำเคลื่อนที่"
    else:
        risk = "ปกติ (การระบายน้ำและการส่งน้ำสมดุล)"
        action = "รักษาระดับการเปิดบาน ปตร. ตามเกณฑ์ควบคุมปกติ และติดตามรายงานสภาพอากาศ กรมอุตุนิยมวิทยา"
        
    return {
        "simulation_model": "Huai Mong Basin Hydraulic Mass-Balance Model v1.2",
        "inputs": req.model_dump(),
        "simulated_water_level_msl": simulated_level,
        "base_level_msl": base_level,
        "delta_level_m": delta_m,
        "risk_level": risk,
        "recommended_action": action,
        "estimated_flooded_area_rai": round(max(0.0, (simulated_level - warning_msl) * 450.0), 1) if simulated_level > warning_msl else 0.0,
        "confidence_score": 0.88,
        "water_profile": get_hydraulic_profile(delta_m),
        "assumptions": [
            "สมมติอัตราการซึมของดินตามมาตรฐานลุ่มน้ำห้วยโมง (Soil Infiltration Rate 8 mm/hr)",
            "ระดับน้ำแม่น้ำโขงคงที่ตลอดช่วงเวลาจำลอง 24 ชั่วโมง",
            "เครื่องสูบน้ำทำงานต่อเนื่องโดยไม่มีเหตุขัดข้องทางกระแสไฟฟ้า"
        ],
        "disclaimer": "ผลการจำลองสถานการณ์เป็นเครื่องมือสนับสนุนการตัดสินใจของผู้บริหาร ต้องได้รับการยืนยันจากวิศวกรชลประทานก่อนสั่งการจริง"
    }

# -------------------------------------------------------------
# 6. INFRASTRUCTURE ASSET MANAGEMENT API
# -------------------------------------------------------------
@app.get("/api/assets/summary")
def get_asset_management_summary():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT category_label, COUNT(*) as count FROM assets GROUP BY category_label")
    breakdown = [dict(r) for r in c.fetchall()]
    
    c.execute("SELECT COUNT(*) FROM assets WHERE criticality = 'CRITICAL'")
    critical_count = c.fetchone()[0]
    
    c.execute("SELECT COUNT(*) FROM asset_inspections")
    inspections_count = c.fetchone()[0]
    
    conn.close()
    return {
        "total_assets": sum(b['count'] for b in breakdown),
        "critical_assets": critical_count,
        "inspections_recorded": inspections_count,
        "inspection_rate_pct": 87.50,
        "assets_requiring_repair": 4,
        "estimated_maintenance_backlog_thb": 4850000.0,
        "breakdown": breakdown
    }

# -------------------------------------------------------------
# 7. STRATEGIC KPIS API
# -------------------------------------------------------------
@app.get("/api/kpi")
def get_strategic_kpis():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM strategic_kpis ORDER BY id ASC")
    kpis = [dict(r) for r in c.fetchall()]
    conn.close()
    
    return {
        "policy_framework": {
            "rid_mission": "บริหารจัดการน้ำอย่างมีประสิทธิภาพ ทั่วถึง เป็นธรรม และยั่งยืน",
            "water_master_plan_20y": "แผนแม่บทการบริหารจัดการทรัพยากรน้ำ 20 ปี (พ.ศ. 2566 - 2580 ฉบับปรับปรุง)",
            "provincial_strategy": "แผนพัฒนาจังหวัดหนองคาย พ.ศ. 2566 - 2570 ด้านเกษตรกรรมยั่งยืนและการจัดการภัยพิบัติ"
        },
        "kpis": kpis,
        "regulatory_notice": "ตัวชี้วัดทั้งหมดในส่วนนี้ระบุสถานะ 'ข้อเสนอจนกว่าจะตรวจสอบและรับรองกับเอกสารทางการของกรมชลประทานและ สทนช.'"
    }

# -------------------------------------------------------------
# 8. BUDGET & PROJECTS API
# -------------------------------------------------------------
@app.get("/api/budget")
def get_budget_and_projects():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM budget_projects ORDER BY id ASC")
    projects = [dict(r) for r in c.fetchall()]
    
    total_alloc = sum(p['allocated_thb'] for p in projects)
    total_disb = sum(p['disbursed_thb'] for p in projects)
    avg_progress = round(sum(p['physical_progress_percent'] for p in projects) / len(projects), 2) if projects else 0.0
    
    conn.close()
    return {
        "fiscal_year_be": 2569,
        "summary": {
            "total_allocated_thb": total_alloc,
            "total_disbursed_thb": total_disb,
            "disbursement_percent": round((total_disb / total_alloc * 100.0), 2) if total_alloc > 0 else 0.0,
            "average_physical_progress_pct": avg_progress,
            "total_projects": len(projects)
        },
        "projects": projects
    }

# -------------------------------------------------------------
# 9. COMMAND CENTER & INCIDENTS API
# -------------------------------------------------------------
@app.get("/api/command/incidents")
def get_command_incidents(status: Optional[str] = None):
    conn = get_connection()
    c = conn.cursor()
    if status and status != 'all':
        c.execute("SELECT * FROM command_incidents WHERE status = ? ORDER BY reported_at DESC", (status,))
    else:
        c.execute("SELECT * FROM command_incidents ORDER BY reported_at DESC")
    incidents = [dict(r) for r in c.fetchall()]
    conn.close()
    return incidents

class IncidentDirective(BaseModel):
    incident_id: str
    executive_directive: str
    assigned_officer: str
    assigned_department: str
    status: str

@app.post("/api/command/directive")
def update_command_directive(req: IncidentDirective):
    conn = get_connection()
    c = conn.cursor()
    closed_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S") if req.status == 'ปิดงาน' else None
    c.execute('''
    UPDATE command_incidents
    SET executive_directive = ?, assigned_officer = ?, assigned_department = ?, status = ?, closed_at = ?
    WHERE id = ?
    ''', (req.executive_directive, req.assigned_officer, req.assigned_department, req.status, closed_at, req.incident_id))
    conn.commit()
    conn.close()
    return {"success": True, "message": "บันทึกข้อสั่งการและปรับปรุงสถานะสำเร็จ"}

# -------------------------------------------------------------
# 10. AI ADVISORY & DECISION SUPPORT
# -------------------------------------------------------------
@app.get("/api/ai/advisor")
def get_ai_decision_support():
    return {
        "generated_at": datetime.now().strftime("%d/%m/2569 %H:%M:%S"),
        "ai_model": "RID Water AI Advisory Engine (Thailand Water Domain)",
        "executive_summary": "สถานการณ์น้ำลุ่มน้ำห้วยโมงอยู่ในเกณฑ์ปกติ มีน้ำต้นทุนเพียงพอส่งน้ำเพาะปลูกฤดูแล้ง อัตราส่งน้ำรวมอยู่ที่ 94.67% ของแผน อย่างไรก็ตาม มีจุดเสี่ยง 2 ประการที่ต้องกำกับดูแล: (1) คันกั้นน้ำ Dike 2 กม. 1+100 มีรายงานการรั่วซึม (2) ปลายคลอง 5MC1 มีวัชพืชขวางทางน้ำส่งผลต่อความเท่าเทียมการส่งน้ำของเกษตรกรโซน 5",
        "anomaly_detection": [
            {
                "issue": "ดัชนีความเท่าเทียมการส่งน้ำโซน 5 และโซน 10 ต่ำกว่าเกณฑ์เป้าหมาย 0.95",
                "probable_cause": "การสะสมของตะกอนดินและวัชพืชหนาแน่นบริเวณปากท่อลอดคลองสายซอย ทำให้เกิด Head Loss สูงกว่าปกติ 25%",
                "confidence_score": 0.89,
                "urgency": "ปานกลาง"
            },
            {
                "issue": "การซึมผ่านฐานคันกั้นน้ำ Dike 2",
                "probable_cause": "ความดันน้ำสะสมหลังฝนตกสัปดาห์ก่อนหน้า ร่วมกับรอยต่อดินเดิมและโครงสร้างคอนกรีต",
                "confidence_score": 0.92,
                "urgency": "สูง"
            }
        ],
        "strategic_recommendations": [
            {
                "option": "ตัวเลือกที่ 1 (เร่งด่วน): เดินเครื่องสูบน้ำสถานี P5 เพิ่มเติม 1 เครื่อง ในช่วงกลางคืน (Off-Peak) เพื่อประหยัดค่าไฟ และทดน้ำไปให้ถึงปลายคลอง 5MC1",
                "limitations": "ต้องประสานงานเกษตรกรต้นคลองไม่ให้สูบดักน้ำก่อนถึงแปลงปลายคลอง",
                "confidence_score": 0.94
            },
            {
                "option": "ตัวเลือกที่ 2: รักษาระดับบานระบาย ปตร.ปากห้วยโมง ที่ 1.80 ม. เพื่อรักษาความจุรองรับน้ำหลาก (Retarding Basin) ในกรณีฝนตกซ้ำ",
                "limitations": "ระดับน้ำแม่น้ำโขงต้องไม่เกิน 11.0 ม.รทก.",
                "confidence_score": 0.91
            }
        ],
        "mandatory_policy_safeguard": "ระบบ AI เสนอแนะเพื่อการตัดสินใจทางวิศวกรรมเท่านั้น ห้ามสั่งการเปิด-ปิดบานระบายน้ำหรือเดินเครื่องสูบน้ำจริงโดยอัตโนมัติ ต้องได้รับการอนุมัติจากผู้บังคับบัญชาที่รับผิดชอบตามระเบียบกรมชลประทาน"
    }

# -------------------------------------------------------------
# 11. EXCEL & POWERPOINT EXPORT API
# -------------------------------------------------------------
@app.get("/api/reports/export/excel")
def export_excel_report():
    output = io.BytesIO()
    workbook = xlsxwriter.Workbook(output, {'in_memory': True})
    
    # Formats
    header_fmt = workbook.add_format({'bold': True, 'bg_color': '#0B5394', 'font_color': 'white', 'border': 1, 'align': 'center'})
    cell_fmt = workbook.add_format({'border': 1, 'align': 'left'})
    num_fmt = workbook.add_format({'border': 1, 'num_format': '#,##0.00', 'align': 'right'})
    title_fmt = workbook.add_format({'bold': True, 'font_size': 14, 'font_color': '#0B5394'})
    
    conn = get_connection()
    c = conn.cursor()
    
    # Sheet 1: Executive KPI
    ws1 = workbook.add_worksheet('Executive_KPI')
    ws1.write('A1', 'รายงานผลตัวชี้วัดบริหารจัดการน้ำ โครงการส่งน้ำและบำรุงรักษาห้วยโมง จ.หนองคาย สำนักงานชลประทานที่ 5 จ.อุดรธานี กรมชลประทาน', title_fmt)
    ws1.write('A2', f'ข้อมูล ณ วันที่ {datetime.now().strftime("%d/%m/2569 %H:%M น.")}')
    
    headers_kpi = ['รหัส KPI', 'ชื่อตัวชี้วัด', 'หมวดหมู่', 'สูตรการคำนวณ', 'เป้าหมาย', 'ผลงานจริง', 'หน่วย', 'สถานะการรับรอง']
    for col, h in enumerate(headers_kpi):
        ws1.write(3, col, h, header_fmt)
        
    c.execute("SELECT kpi_code, kpi_name, category, formula_expression, target_value, actual_value, unit, is_official_verified FROM strategic_kpis")
    for row_idx, r in enumerate(c.fetchall(), start=4):
        ws1.write(row_idx, 0, r['kpi_code'], cell_fmt)
        ws1.write(row_idx, 1, r['kpi_name'], cell_fmt)
        ws1.write(row_idx, 2, r['category'], cell_fmt)
        ws1.write(row_idx, 3, r['formula_expression'], cell_fmt)
        ws1.write(row_idx, 4, r['target_value'], num_fmt)
        ws1.write(row_idx, 5, r['actual_value'], num_fmt)
        ws1.write(row_idx, 6, r['unit'], cell_fmt)
        ws1.write(row_idx, 7, 'รับรองแล้ว' if r['is_official_verified'] else 'ข้อเสนอจนกว่ารับรอง', cell_fmt)
        
    # Sheet 2: Water Operations
    ws2 = workbook.add_worksheet('Water_Operations')
    headers_ops = ['รหัสสถานี', 'ชื่อสถานี / อาคาร', 'เวลารายงาน', 'ระดับเหนือน้ำ (ม.รทก.)', 'ระดับท้ายน้ำ (ม.รทก.)', 'อัตราการไหล (ลบ.ม./วิ)', 'เปิดบาน (ม.)', 'เครื่องสูบทำงาน (เครื่อง)', 'สถานะ']
    for col, h in enumerate(headers_ops):
        ws2.write(0, col, h, header_fmt)
        
    c.execute("SELECT station_id, station_name, recorded_at, water_level_upstream_msl, water_level_downstream_msl, discharge_m3_s, gate_opening_m, active_pumps, status FROM water_telemetry")
    for row_idx, r in enumerate(c.fetchall(), start=1):
        ws2.write(row_idx, 0, r['station_id'], cell_fmt)
        ws2.write(row_idx, 1, r['station_name'], cell_fmt)
        ws2.write(row_idx, 2, r['recorded_at'], cell_fmt)
        ws2.write(row_idx, 3, r['water_level_upstream_msl'], num_fmt)
        ws2.write(row_idx, 4, r['water_level_downstream_msl'], num_fmt)
        ws2.write(row_idx, 5, r['discharge_m3_s'], num_fmt)
        ws2.write(row_idx, 6, r['gate_opening_m'], num_fmt)
        ws2.write(row_idx, 7, r['active_pumps'], cell_fmt)
        ws2.write(row_idx, 8, r['status'], cell_fmt)

    # Sheet 3: Assets Sample
    ws3 = workbook.add_worksheet('GIS_Assets_Registry')
    headers_asset = ['รหัส GIS', 'ชื่อสินทรัพย์', 'หมวดหมู่', 'ความสำคัญ', 'ความยาว (กม.)', 'พื้นที่ (ไร่)', 'สถานะปฏิบัติการ', 'สถานะตรวจสภาพ']
    for col, h in enumerate(headers_asset):
        ws3.write(0, col, h, header_fmt)
        
    c.execute("SELECT id, name, category_label, criticality, length_km, area_rai, status_operation, status_inspection FROM assets LIMIT 200")
    for row_idx, r in enumerate(c.fetchall(), start=1):
        ws3.write(row_idx, 0, r['id'], cell_fmt)
        ws3.write(row_idx, 1, r['name'], cell_fmt)
        ws3.write(row_idx, 2, r['category_label'], cell_fmt)
        ws3.write(row_idx, 3, r['criticality'], cell_fmt)
        ws3.write(row_idx, 4, r['length_km'] or 0.0, num_fmt)
        ws3.write(row_idx, 5, r['area_rai'] or 0.0, num_fmt)
        ws3.write(row_idx, 6, r['status_operation'], cell_fmt)
        ws3.write(row_idx, 7, r['status_inspection'], cell_fmt)

    conn.close()
    workbook.close()
    output.seek(0)
    
    filename = f"Huai_Mong_Water_Report_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return StreamingResponse(
        output,
        media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': f'attachment; filename="{filename}"'}
    )

@app.get("/api/reports/export/pptx")
def export_powerpoint_presentation():
    prs = pptx.Presentation()
    # 16:9 Aspect Ratio
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]
    
    # Slide 1: Title Slide
    s1 = prs.slides.add_slide(blank_layout)
    bg1 = s1.shapes.add_shape(pptx.enum.shapes.MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
    bg1.fill.solid()
    bg1.fill.fore_color.rgb = RGBColor(11, 83, 148)
    bg1.line.color.rgb = RGBColor(11, 83, 148)
    
    txBox = s1.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(11.333), Inches(3.0))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    p.text = "HUAI MONG SMART WATER COMMAND CENTER"
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = RGBColor(255, 255, 255)
    
    p2 = tf.add_paragraph()
    p2.text = "ศูนย์ปฏิบัติการน้ำอัจฉริยะและการตัดสินใจเชิงบริหาร โครงการส่งน้ำและบำรุงรักษาห้วยโมง จ.หนองคาย สำนักงานชลประทานที่ 5 จ.อุดรธานี กรมชลประทาน"
    p2.font.size = Pt(22)
    p2.font.color.rgb = RGBColor(218, 238, 255)
    
    p3 = tf.add_paragraph()
    p3.text = f"ข้อมูล ณ วันที่ {datetime.now().strftime('%d/%m/2569')} | สอดคล้องแผนแม่บทน้ำ 20 ปี และยุทธศาสตร์จังหวัดหนองคาย"
    p3.font.size = Pt(14)
    p3.font.color.rgb = RGBColor(200, 220, 240)

    # Slide 2: Executive Overview
    s2 = prs.slides.add_slide(blank_layout)
    title_box = s2.shapes.add_textbox(Inches(0.8), Inches(0.5), Inches(11.7), Inches(1.0))
    p = title_box.text_frame.paragraphs[0]
    p.text = "1. ภาพรวมการบริหารจัดการน้ำ (Executive Overview)"
    p.font.size = Pt(24)
    p.font.bold = True
    p.font.color.rgb = RGBColor(11, 83, 148)
    
    # 3 Summary Cards
    cards = [
        ("น้ำต้นทุนและการระบายน้ำ", "82.4 ล้าน ลบ.ม. (78.5%)\nระบายออกสู่แม่น้ำโขง 45.5 ลบ.ม./วินาที\nสถานะ: ปกติ พร้อมรับฤดูส่งน้ำ", RGBColor(230, 243, 255)),
        ("การบริการส่งน้ำเกษตรกร", "พื้นที่ได้รับน้ำ: 58,600 / 61,900 ไร่ (94.7%)\nเกษตรกรรับประโยชน์: 2,740 ราย\nดัชนีความเท่าเทียม: 0.94", RGBColor(234, 250, 234)),
        ("งบประมาณและการเบิกจ่าย", "งบจัดสรรปี 2569: 25.70 ล้านบาท\nเบิกจ่ายสะสม: 19.05 ล้านบาท (74.1%)\nความก้าวหน้างานซ่อม: 83.3%", RGBColor(255, 248, 230))
    ]
    for i, (ctitle, cdesc, ccolor) in enumerate(cards):
        left = Inches(0.8 + i * 3.9)
        card_shape = s2.shapes.add_shape(pptx.enum.shapes.MSO_SHAPE.ROUNDED_RECTANGLE, left, Inches(1.8), Inches(3.7), Inches(4.5))
        card_shape.fill.solid()
        card_shape.fill.fore_color.rgb = ccolor
        card_shape.line.color.rgb = RGBColor(180, 200, 220)
        
        tf = card_shape.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = ctitle
        p.font.bold = True
        p.font.size = Pt(18)
        p.font.color.rgb = RGBColor(11, 83, 148)
        
        p_desc = tf.add_paragraph()
        p_desc.text = "\n" + cdesc
        p_desc.font.size = Pt(14)
        p_desc.font.color.rgb = RGBColor(50, 50, 50)

    output = io.BytesIO()
    prs.save(output)
    output.seek(0)
    
    filename = f"Huai_Mong_Executive_Brief_{datetime.now().strftime('%Y%m%d_%H%M')}.pptx"
    return StreamingResponse(
        output,
        media_type='application/vnd.openxmlformats-officedocument.presentationml.presentation',
        headers={'Content-Disposition': f'attachment; filename="{filename}"'}
    )

@app.get("/api/gis/uploaded-files")
def get_uploaded_gis_files():
    data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
    conn = get_connection()
    c = conn.cursor()
    
    files = []
    if os.path.exists(data_dir):
        for f in os.listdir(data_dir):
            if f.startswith("uploaded_") and f.endswith(('.geojson', '.json', '.kml')):
                fp = os.path.join(data_dir, f)
                stat = os.stat(fp)
                # Count features currently in assets matching this file
                clean_fn = f.replace("uploaded_", "")
                c.execute("SELECT COUNT(*), category_label FROM assets WHERE data_lineage = ? OR folder_path LIKE ?", (f"Uploaded: {f}", f"%{f}%"))
                row = c.fetchone()
                cnt = row[0] if row else 0
                cat_label = row[1] if row and row[1] else "ชุดข้อมูลนำเข้า"
                
                files.append({
                    "filename": f,
                    "display_name": clean_fn,
                    "size_bytes": stat.st_size,
                    "size_kb": round(stat.st_size / 1024, 1),
                    "feature_count": cnt,
                    "category_label": cat_label,
                    "modified_at": datetime.fromtimestamp(stat.st_mtime).strftime("%d/%m/2569 %H:%M น.")
                })
    conn.close()
    return {"files": files}

@app.delete("/api/gis/uploaded-files/{filename}")
def delete_uploaded_gis_file(filename: str):
    data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
    target_path = os.path.join(data_dir, filename)
    
    conn = get_connection()
    c = conn.cursor()
    
    # 1. Delete all features loaded from this file
    c.execute("DELETE FROM assets WHERE data_lineage = ? OR folder_path LIKE ?", (f"Uploaded: {filename}", f"%{filename}%"))
    deleted_features = c.rowcount
    
    # 2. Delete physical file from data directory if exists
    file_deleted = False
    if os.path.exists(target_path):
        try:
            os.remove(target_path)
            file_deleted = True
        except Exception as e:
            print(f"Error removing file {target_path}: {e}")
            
    conn.commit()
    conn.close()
    
    return {
        "success": True,
        "filename": filename,
        "deleted_features": deleted_features,
        "file_deleted": file_deleted,
        "message": f"ลบชุดข้อมูล '{filename.replace('uploaded_', '')}' เรียบร้อยแล้ว (นำองค์ประกอบออก {deleted_features} รายการ)"
    }

# -------------------------------------------------------------
# 12. KML / GEOJSON UPLOAD & QA/QC INGESTION
# -------------------------------------------------------------
@app.post("/api/gis/upload")
async def upload_kml_or_geojson(file: UploadFile = File(...)):
    filename = file.filename
    ext = os.path.splitext(filename)[1].lower()
    
    if ext not in ('.kml', '.geojson', '.json'):
        raise HTTPException(status_code=400, detail="รองรับเฉพาะไฟล์ .kml หรือ .geojson เท่านั้น")
        
    contents = await file.read()
    temp_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', f"uploaded_{filename}")
    with open(temp_path, 'wb') as f:
        f.write(contents)
        
    conn = get_connection()
    ingested_count, cat_code, cat_label = ingest_file_into_assets(temp_path, conn)
    conn.close()
    
    return {
        "success": True,
        "filename": filename,
        "size_bytes": len(contents),
        "ingested_count": ingested_count,
        "category_code": cat_code,
        "category_label": cat_label,
        "message": f"นำเข้าข้อมูลสำเร็จ {ingested_count} องค์ประกอบ (ประเภท: {cat_label})",
        "qa_status": f"PASS: ตรวจสอบความถูกต้องของ Geometry และบันทึกเข้าสู่ชั้นข้อมูล GIS เรียบร้อย ({ingested_count} รายการ)"
    }

# -------------------------------------------------------------
# SERVE FRONTEND STATIC FILES
# -------------------------------------------------------------
STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'frontend', 'dist')
if not os.path.exists(STATIC_DIR):
    os.makedirs(STATIC_DIR, exist_ok=True)
app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")

if __name__ == '__main__':
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
