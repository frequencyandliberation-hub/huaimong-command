import unittest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'backend'))

from fastapi.testclient import TestClient
from main import app

class TestHuaiMongAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)

    def test_overview_endpoint(self):
        response = self.client.get("/api/overview")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("project_name", data)
        self.assertIn("โครงการส่งน้ำและบำรุงรักษาห้วยโมง", data["project_name"])
        self.assertIn("kpi_summary", data)
        self.assertGreaterEqual(data["kpi_summary"]["total_gis_features"], 1723)

    def test_gis_features_endpoint(self):
        response = self.client.get("/api/gis/features?limit=50")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["type"], "FeatureCollection")
        self.assertGreater(len(data["features"]), 0)
        feat = data["features"][0]
        self.assertIn("geometry", feat)
        self.assertIn("properties", feat)
        self.assertIn("category_label", feat["properties"])

    def test_gis_categories(self):
        response = self.client.get("/api/gis/categories")
        self.assertEqual(response.status_code, 200)
        cats = response.json()
        self.assertGreater(len(cats), 0)

    def test_water_operations(self):
        response = self.client.get("/api/water-operations")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("summary", data)
        self.assertEqual(len(data["stations"]), 10)

    def test_irrigation_service(self):
        response = self.client.get("/api/irrigation-service")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(len(data["zones"]), 9)
        self.assertGreaterEqual(data["summary"]["upstream_downstream_equity_index"], 0.90)

    def test_flood_drought_and_simulation(self):
        res1 = self.client.get("/api/flood-drought")
        self.assertEqual(res1.status_code, 200)
        data1 = res1.json()
        self.assertGreaterEqual(len(data1["stations"]), 3)
        
        payload = {
            "rainfall_added_mm": 60.0,
            "gate_opening_m": 2.0,
            "active_pumps": 4,
            "mekong_level_msl": 10.5
        }
        res2 = self.client.post("/api/flood-drought/simulate", json=payload)
        self.assertEqual(res2.status_code, 200)
        data2 = res2.json()
        self.assertIn("simulated_water_level_msl", data2)
        self.assertIn("confidence_score", data2)

    def test_strategic_kpis(self):
        response = self.client.get("/api/kpi")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(len(data["kpis"]), 7)
        for k in data["kpis"]:
            self.assertIn("is_official_verified", k)
            self.assertIn("formula_expression", k)

    def test_budget(self):
        response = self.client.get("/api/budget")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["summary"]["total_projects"], 4)
        self.assertGreater(data["summary"]["disbursement_percent"], 0)

    def test_ai_advisor(self):
        response = self.client.get("/api/ai/advisor")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("mandatory_policy_safeguard", data)
        self.assertIn("AI เสนอแนะเพื่อการตัดสินใจ", data["mandatory_policy_safeguard"])

    def test_excel_export(self):
        response = self.client.get("/api/reports/export/excel")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers["content-type"], "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.assertGreater(len(response.content), 1000)

    def test_powerpoint_export(self):
        response = self.client.get("/api/reports/export/pptx")
        self.assertEqual(response.status_code, 200)
        self.assertIn("presentationml", response.headers["content-type"])
        self.assertGreater(len(response.content), 1000)

if __name__ == '__main__':
    unittest.main()
